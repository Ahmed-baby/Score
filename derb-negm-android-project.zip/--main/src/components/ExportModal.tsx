import React, { useState } from 'react';
import { Download, Check, Copy, Share2, X, ExternalLink } from 'lucide-react';

interface ExportModalProps {
  isOpen: boolean;
  onClose: () => void;
  imageUrl: string | null;
  fileName: string;
}

export const ExportModal: React.FC<ExportModalProps> = ({
  isOpen,
  onClose,
  imageUrl,
  fileName,
}) => {
  const [copied, setCopied] = useState(false);
  const [shared, setShared] = useState(false);

  if (!isOpen || !imageUrl) return null;

  const handleDownloadAgain = () => {
    const link = document.createElement('a');
    link.download = fileName;
    link.href = imageUrl;
    link.click();
  };

  const handleCopyToClipboard = async () => {
    try {
      const res = await fetch(imageUrl);
      const blob = await res.blob();
      await navigator.clipboard.write([
        new ClipboardItem({ 'image/png': blob }),
      ]);
      setCopied(true);
      setTimeout(() => setCopied(false), 3000);
    } catch {
      // Fallback
      navigator.clipboard.writeText(imageUrl);
      setCopied(true);
      setTimeout(() => setCopied(false), 3000);
    }
  };

  const handleShare = async () => {
    if (navigator.share) {
      try {
        const res = await fetch(imageUrl);
        const blob = await res.blob();
        const file = new File([blob], fileName, { type: 'image/png' });
        await navigator.share({
          title: 'نتيجة مباراة نادي ديرب نجم',
          text: 'تصميم نتيجة اللقاء بجودة عالية',
          files: [file],
        });
        setShared(true);
        setTimeout(() => setShared(false), 2000);
      } catch {
        // User cancelled or unsupported
      }
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg bg-neutral-900 border border-neutral-700/80 rounded-3xl p-6 shadow-2xl text-right">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 left-4 p-2 text-neutral-400 hover:text-white rounded-xl hover:bg-neutral-800 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
            <Check className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-bold text-lg text-white">
              تم إنشاء التصميم بنجاح!
            </h3>
            <p className="text-xs text-neutral-400 font-mono">
              {fileName} (1080 × 1350 px)
            </p>
          </div>
        </div>

        {/* Thumbnail Preview */}
        <div className="relative rounded-2xl overflow-hidden border border-neutral-800 bg-neutral-950 max-h-72 flex items-center justify-center mb-6">
          <img
            src={imageUrl}
            alt="معاينة البوستر الجاهز"
            className="max-h-72 w-auto object-contain"
          />
          <div className="absolute bottom-2 right-2 px-2.5 py-1 rounded-md bg-black/70 text-[10px] text-emerald-300 font-mono backdrop-blur-sm">
            PNG عالي الدقة
          </div>
        </div>

        {/* Action Buttons */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
          <button
            type="button"
            onClick={handleDownloadAgain}
            className="w-full flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-sm shadow-lg shadow-emerald-950 transition-all cursor-pointer"
          >
            <Download className="w-4 h-4" />
            <span>تحميل الصورة مجدداً</span>
          </button>

          <button
            type="button"
            onClick={handleCopyToClipboard}
            className="w-full flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-200 font-bold text-sm border border-neutral-700 transition-all cursor-pointer"
          >
            {copied ? (
              <>
                <Check className="w-4 h-4 text-emerald-400" />
                <span className="text-emerald-400">تم نسخ الصورة!</span>
              </>
            ) : (
              <>
                <Copy className="w-4 h-4" />
                <span>نسخ إلى الحافظة</span>
              </>
            )}
          </button>
        </div>

        {/* Web Share if supported */}
        {typeof navigator !== 'undefined' && 'share' in navigator && (
          <button
            type="button"
            onClick={handleShare}
            className="w-full mt-2.5 flex items-center justify-center gap-2 py-2 px-4 rounded-xl bg-neutral-950 hover:bg-neutral-800 text-neutral-300 font-medium text-xs border border-neutral-800 transition-colors"
          >
            <Share2 className="w-3.5 h-3.5 text-emerald-400" />
            <span>مشاركة مباشرة عبر تطبيقات التواصل (واتساب / فيسبوك)</span>
          </button>
        )}
      </div>
    </div>
  );
};
