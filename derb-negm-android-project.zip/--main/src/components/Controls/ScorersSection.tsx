import React from 'react';
import { MatchData } from '../../types';
import { ChevronDown, ChevronUp, CheckSquare, Square } from 'lucide-react';

interface ScorersSectionProps {
  data: MatchData;
  onChange: (updated: Partial<MatchData>) => void;
}

export const ScorersSection: React.FC<ScorersSectionProps> = ({
  data,
  onChange,
}) => {
  return (
    <div className="p-4 md:p-5 rounded-2xl bg-neutral-900/60 border border-neutral-800 space-y-4">
      {/* Toggle header */}
      <div className="flex items-center justify-between">
        <label
          className="flex items-center gap-2.5 cursor-pointer"
          onClick={() => onChange({ showScorers: !data.showScorers })}
        >
          {data.showScorers ? (
            <CheckSquare className="w-4 h-4 text-emerald-400" />
          ) : (
            <Square className="w-4 h-4 text-neutral-500" />
          )}
          <span className="font-bold text-sm text-neutral-100">
            إظهار هدافي المباراة (مسجلو الأهداف)
          </span>
        </label>

        <span className="text-xs text-neutral-400">
          اختياري
        </span>
      </div>

      {data.showScorers && (
        <div className="pt-2 grid grid-cols-1 sm:grid-cols-2 gap-4 border-t border-neutral-800/80">
          <div>
            <label className="block text-xs font-semibold text-emerald-400 mb-1.5">
              هدافو {data.team1.name || 'الفريق الأول'}
            </label>
            <textarea
              rows={2}
              value={data.scorersTeam1}
              onChange={(e) => onChange({ scorersTeam1: e.target.value })}
              placeholder="مثال: أحمد حسن 23' • محمد صلاح 67'"
              className="w-full bg-neutral-950/80 border border-neutral-700/80 focus:border-emerald-500 rounded-xl p-3 text-xs text-white outline-none resize-none leading-relaxed"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-neutral-300 mb-1.5">
              هدافو {data.team2.name || 'الفريق الثاني'}
            </label>
            <textarea
              rows={2}
              value={data.scorersTeam2}
              onChange={(e) => onChange({ scorersTeam2: e.target.value })}
              placeholder="مثال: محمود فتحي 45' (ض.ج)"
              className="w-full bg-neutral-950/80 border border-neutral-700/80 focus:border-emerald-500 rounded-xl p-3 text-xs text-white outline-none resize-none leading-relaxed"
            />
          </div>

          <div className="col-span-1 sm:col-span-2">
            <label className="block text-xs font-semibold text-amber-400 mb-1.5">
              ملاحظة إضافية (مثل: بعد التمديد / ركلات الترجيح)
            </label>
            <input
              type="text"
              value={data.extraInfo}
              onChange={(e) => onChange({ extraInfo: e.target.value })}
              placeholder="مثال: بعد التمديد لشوطين إضافيين"
              className="w-full bg-neutral-950/80 border border-neutral-700/80 focus:border-amber-500 rounded-xl px-3 py-2 text-xs text-white outline-none"
            />
          </div>
        </div>
      )}
    </div>
  );
};
