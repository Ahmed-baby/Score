import React from 'react';
import { TemplateId } from '../../types';
import { Sparkles, Palette, Camera, Sun, Award } from 'lucide-react';

interface TemplatePickerProps {
  currentTemplate: TemplateId;
  onSelect: (id: TemplateId) => void;
}

interface TemplateOption {
  id: TemplateId;
  title: string;
  subtitle: string;
  badge: string;
  icon: React.ReactNode;
  bgPreview: string;
}

export const TemplatePicker: React.FC<TemplatePickerProps> = ({
  currentTemplate,
  onSelect,
}) => {
  const TEMPLATES: TemplateOption[] = [
    {
      id: 'dark-pro',
      title: 'Dark Professional',
      subtitle: 'الخلفية الخضراء الداكنة الملكية وإضاءة رياضية وتفاصيل ذهبية',
      badge: 'الافتراضي • ديرب نجم',
      icon: <Sparkles className="w-4 h-4 text-emerald-400" />,
      bgPreview: 'from-[#031c10] via-[#083820] to-[#010e07]',
    },
    {
      id: 'modern-light',
      title: 'Modern Light',
      subtitle: 'خلفية بيضاء نقية مع خطوط زمردية وتصميم أوروبي عصري',
      badge: 'نهاري حديث',
      icon: <Sun className="w-4 h-4 text-amber-500" />,
      bgPreview: 'from-slate-100 via-white to-emerald-50',
    },
    {
      id: 'match-photo',
      title: 'Match Photo',
      subtitle: 'يستخدم صورة المباراة مع تدرجات سينمائية لحفظ وضوح النتيجة',
      badge: 'كادر حقيقي',
      icon: <Camera className="w-4 h-4 text-sky-400" />,
      bgPreview: 'from-neutral-900 via-emerald-950 to-neutral-950',
    },
    {
      id: 'stadium-neon',
      title: 'Stadium Glow',
      subtitle: 'أجواء ليلة الملعب مع توهج كشافات الاستاد وألوان زاهية',
      badge: 'مباريات ليلية',
      icon: <Palette className="w-4 h-4 text-emerald-300" />,
      bgPreview: 'from-[#02130a] via-emerald-900 to-[#032014]',
    },
    {
      id: 'classic-gold',
      title: 'Classic Gold',
      subtitle: 'إطار ذهبي ملكي فاخر وتصميم كؤوس وبطولات مرموقة',
      badge: 'البطولة الذهبية',
      icon: <Award className="w-4 h-4 text-yellow-400" />,
      bgPreview: 'from-[#042012] via-[#09351e] to-[#021008]',
    },
  ];

  return (
    <div className="p-4 md:p-5 rounded-2xl bg-neutral-900/60 border border-neutral-800 space-y-3">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-2.5 h-2.5 rounded-full bg-emerald-400 ring-4 ring-emerald-400/20" />
          <h3 className="font-bold text-base text-neutral-100">
            اختيار القالب (Template)
          </h3>
        </div>
        <span className="text-xs text-neutral-400">
          5 قوالب احترافية
        </span>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5">
        {TEMPLATES.map((tmpl) => {
          const isSelected = currentTemplate === tmpl.id;
          return (
            <button
              key={tmpl.id}
              type="button"
              onClick={() => onSelect(tmpl.id)}
              className={`p-3 rounded-xl text-right transition-all flex flex-col justify-between border cursor-pointer ${
                isSelected
                  ? 'border-emerald-500 bg-emerald-950/40 ring-2 ring-emerald-500/30 shadow-md shadow-emerald-950/40'
                  : 'border-neutral-800 hover:border-neutral-700 bg-neutral-950/50 hover:bg-neutral-800/40'
              }`}
            >
              {/* Header inside button */}
              <div className="flex items-start justify-between w-full mb-2">
                <span className="text-xs font-semibold px-2 py-0.5 rounded bg-neutral-800/80 text-neutral-300">
                  {tmpl.badge}
                </span>
                <div className="p-1 rounded bg-neutral-900">
                  {tmpl.icon}
                </div>
              </div>

              {/* Title & Preview gradient bar */}
              <div>
                <h4 className="font-bold text-sm text-white mb-0.5">
                  {tmpl.title}
                </h4>
                <p className="text-[11px] text-neutral-400 leading-snug line-clamp-2">
                  {tmpl.subtitle}
                </p>
              </div>

              {/* Mini gradient strip preview */}
              <div
                className={`mt-2.5 h-2 rounded-full w-full bg-gradient-to-r ${tmpl.bgPreview} border border-white/10`}
              />
            </button>
          );
        })}
      </div>
    </div>
  );
};
