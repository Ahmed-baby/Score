import React, { useRef, useState } from 'react';
import { TeamData, PresetClub } from '../../types';
import { PRESET_CLUBS } from '../../data/defaultAssets';
import { Upload, X, Plus, Minus, Shield, Sparkles, Loader2, Check } from 'lucide-react';

interface TeamCardProps {
  label: string;
  isMainTeam?: boolean;
  team: TeamData;
  onChange: (updated: TeamData) => void;
  accentColor?: 'emerald' | 'amber' | 'slate';
}

export const TeamCard: React.FC<TeamCardProps> = ({
  label,
  isMainTeam = false,
  team,
  onChange,
  accentColor = isMainTeam ? 'emerald' : 'slate',
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isGeneratingLogo, setIsGeneratingLogo] = useState(false);
  const [generationSuccess, setGenerationSuccess] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const handleScoreChange = (delta: number) => {
    const newScore = Math.max(0, Number(team.score) + delta);
    onChange({ ...team, score: newScore });
  };

  const handleScoreSet = (value: number) => {
    onChange({ ...team, score: value });
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 8 * 1024 * 1024) {
        alert('حجم الصورة كبير جداً، يرجى اختيار صورة أقل من 8 ميجابايت');
        return;
      }
      const reader = new FileReader();
      reader.onload = (event) => {
        if (event.target?.result) {
          onChange({
            ...team,
            logo: event.target.result as string,
          });
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    const file = e.dataTransfer.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        if (event.target?.result) {
          onChange({
            ...team,
            logo: event.target.result as string,
          });
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleApplyPreset = (preset: PresetClub) => {
    onChange({
      ...team,
      name: preset.name,
      logo: preset.logo,
      shortName: preset.shortName,
    });
  };

  const handleClearLogo = () => {
    onChange({ ...team, logo: '' });
  };

  // AI Logo Generator Handler
  const handleGenerateAILogo = async () => {
    const teamName = team.name.trim();
    if (!teamName) {
      setErrorMessage('يرجى كتابة اسم الفريق أولاً حتى يتم توليد الشعار بناءً عليه');
      setTimeout(() => setErrorMessage(null), 4000);
      return;
    }

    setIsGeneratingLogo(true);
    setErrorMessage(null);
    setGenerationSuccess(false);

    try {
      const response = await fetch(`${import.meta.env.VITE_API_BASE_URL || ''}/api/generate-team-logo`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ teamName }),
      });

      if (!response.ok) {
        throw new Error('فشل توليد الشعار');
      }

      const data = await response.json();
      if (data.dataUrl) {
        onChange({
          ...team,
          logo: data.dataUrl,
        });
        setGenerationSuccess(true);
        setTimeout(() => setGenerationSuccess(false), 3000);
      } else {
        throw new Error('لم يتم استلام الشعار بشكل صحيح');
      }
    } catch (err: any) {
      console.error(err);
      setErrorMessage('تعذر توليد الشعار بالذكاء الاصطناعي، يرجى المحاولة لاحقاً');
      setTimeout(() => setErrorMessage(null), 4000);
    } finally {
      setIsGeneratingLogo(false);
    }
  };

  return (
    <div
      className={`p-4 md:p-5 rounded-2xl border transition-all ${
        isMainTeam
          ? 'bg-emerald-950/20 border-emerald-500/30 shadow-lg shadow-emerald-950/20'
          : 'bg-neutral-900/60 border-neutral-800 shadow-md'
      }`}
    >
      {/* Header with Title and Presets */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <div
            className={`w-2.5 h-2.5 rounded-full ${
              accentColor === 'emerald'
                ? 'bg-emerald-400 ring-4 ring-emerald-500/20'
                : 'bg-neutral-400 ring-4 ring-neutral-400/20'
            }`}
          />
          <h3 className="font-bold text-base text-neutral-100">{label}</h3>
          {isMainTeam && (
            <span className="text-xs bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded-md font-medium border border-emerald-500/30">
              الفريق المستضيف
            </span>
          )}
        </div>

        {/* Quick presets */}
        <div className="flex items-center gap-1.5 overflow-x-auto text-xs">
          <span className="text-neutral-400 text-[11px] hidden sm:inline">
            جاهز:
          </span>
          {PRESET_CLUBS.map((preset) => (
            <button
              key={preset.id}
              type="button"
              onClick={() => handleApplyPreset(preset)}
              className="px-2 py-1 rounded bg-neutral-800 hover:bg-neutral-700 text-neutral-300 hover:text-white transition-colors text-[11px] font-medium cursor-pointer"
              title={`اختيار ${preset.name}`}
            >
              {preset.shortName}
            </button>
          ))}
        </div>
      </div>

      {/* Main Grid: Name + Logo + Score */}
      <div className="space-y-4">
        {/* Team Name Input */}
        <div>
          <label className="block text-xs font-semibold text-neutral-300 mb-1.5">
            اسم الفريق
          </label>
          <input
            type="text"
            value={team.name}
            onChange={(e) => onChange({ ...team, name: e.target.value })}
            placeholder="مثال: نادي ديرب نجم"
            className="w-full bg-neutral-950/80 border border-neutral-700/80 focus:border-emerald-500 rounded-xl px-3.5 py-2.5 text-sm text-white placeholder-neutral-500 outline-none transition-all focus:ring-1 focus:ring-emerald-500/50"
          />
        </div>

        {/* Logo and Score Row */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 items-center">
          {/* Logo Section */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-semibold text-neutral-300">
                شعار الفريق
              </label>
              {/* AI Badge Generation Trigger */}
              <button
                type="button"
                onClick={handleGenerateAILogo}
                disabled={isGeneratingLogo}
                className="inline-flex items-center gap-1.5 text-[11px] font-bold text-amber-300 hover:text-amber-200 bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/30 px-2 py-0.5 rounded-md transition-all cursor-pointer active:scale-95 disabled:opacity-50"
                title="توليد شعار ذكي بناءً على اسم الفريق"
              >
                {isGeneratingLogo ? (
                  <>
                    <Loader2 className="w-3 h-3 animate-spin text-amber-400" />
                    <span>جاري التوليد...</span>
                  </>
                ) : generationSuccess ? (
                  <>
                    <Check className="w-3 h-3 text-emerald-400" />
                    <span className="text-emerald-400">تم التوليد!</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-3 h-3 text-amber-400" />
                    <span>توليد شعار بالذكاء الاصطناعي</span>
                  </>
                )}
              </button>
            </div>

            {/* Error feedback if any */}
            {errorMessage && (
              <p className="text-[11px] text-rose-400 mb-1.5">{errorMessage}</p>
            )}

            <div className="flex items-center gap-3">
              {/* Logo Preview & Drop Area */}
              <div
                onDragOver={(e) => e.preventDefault()}
                onDrop={handleDrop}
                onClick={() => fileInputRef.current?.click()}
                className={`relative w-16 h-16 rounded-xl border-2 border-dashed flex items-center justify-center cursor-pointer overflow-hidden transition-all group shrink-0 ${
                  team.logo
                    ? 'border-emerald-500/50 bg-neutral-950 p-1.5'
                    : 'border-neutral-700 hover:border-emerald-500 bg-neutral-900/80'
                }`}
                title="اضغط لتغيير الشعار أو اسحب الصورة هنا"
              >
                {team.logo ? (
                  <img
                    src={team.logo}
                    alt={team.name}
                    className="w-full h-full object-contain filter group-hover:scale-105 transition-transform"
                  />
                ) : (
                  <div className="flex flex-col items-center text-neutral-500 group-hover:text-emerald-400">
                    <Shield className="w-5 h-5" />
                    <span className="text-[9px] mt-0.5">رفع</span>
                  </div>
                )}
                {/* Hover overlay hint */}
                <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity">
                  <Upload className="w-4 h-4 text-emerald-400" />
                </div>
              </div>

              {/* Upload & Clear buttons */}
              <div className="flex flex-col gap-1.5 text-xs">
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/png,image/jpeg,image/webp,image/svg+xml"
                  onChange={handleFileUpload}
                  className="hidden"
                />
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-200 font-medium text-xs transition-colors cursor-pointer"
                >
                  <Upload className="w-3.5 h-3.5 text-emerald-400" />
                  <span>رفع شعار من الجهاز</span>
                </button>
                {team.logo && (
                  <button
                    type="button"
                    onClick={handleClearLogo}
                    className="inline-flex items-center gap-1 px-3 py-1 rounded-lg text-rose-400 hover:bg-rose-950/40 text-[11px] transition-colors cursor-pointer"
                  >
                    <X className="w-3 h-3" />
                    <span>إزالة الشعار</span>
                  </button>
                )}
              </div>
            </div>
          </div>

          {/* Score Stepper & Quick Values */}
          <div className="bg-neutral-950/60 p-3 rounded-xl border border-neutral-800/80">
            <label className="block text-xs font-semibold text-neutral-300 mb-1.5">
              الأهداف المسجلة
            </label>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => handleScoreChange(-1)}
                className="w-9 h-9 rounded-lg bg-neutral-800 hover:bg-neutral-700 active:scale-95 text-neutral-200 flex items-center justify-center transition-all cursor-pointer font-bold"
                aria-label="إنقاص هدف"
              >
                <Minus className="w-4 h-4" />
              </button>

              <input
                type="number"
                min="0"
                max="99"
                value={team.score}
                onChange={(e) => {
                  const val = parseInt(e.target.value, 10);
                  handleScoreSet(isNaN(val) ? 0 : Math.max(0, val));
                }}
                className="w-16 h-9 text-center bg-neutral-900 border border-neutral-700 rounded-lg text-xl font-black text-emerald-400 tabular-nums focus:outline-none focus:border-emerald-500"
              />

              <button
                type="button"
                onClick={() => handleScoreChange(1)}
                className="w-9 h-9 rounded-lg bg-emerald-600 hover:bg-emerald-500 active:scale-95 text-white flex items-center justify-center transition-all cursor-pointer font-bold shadow-md shadow-emerald-950"
                aria-label="زيادة هدف"
              >
                <Plus className="w-4 h-4" />
              </button>
            </div>

            {/* Quick score pills 0-5 */}
            <div className="flex items-center gap-1.5 mt-2.5">
              <span className="text-[10px] text-neutral-400">سريع:</span>
              {[0, 1, 2, 3, 4, 5].map((val) => (
                <button
                  key={val}
                  type="button"
                  onClick={() => handleScoreSet(val)}
                  className={`w-6 h-6 rounded text-xs font-bold transition-all cursor-pointer ${
                    team.score === val
                      ? 'bg-emerald-500 text-black'
                      : 'bg-neutral-800 text-neutral-300 hover:bg-neutral-700'
                  }`}
                >
                  {val}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
