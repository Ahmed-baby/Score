import React, { useRef } from 'react';
import { MatchData } from '../../types';
import { PRESET_BACKGROUNDS } from '../../data/defaultAssets';
import { Upload, Trash2, Sparkles, SlidersHorizontal, Layers, Eye } from 'lucide-react';

interface BackgroundSectionProps {
  data: MatchData;
  onChange: (updated: Partial<MatchData>) => void;
}

export const BackgroundSection: React.FC<BackgroundSectionProps> = ({
  data,
  onChange,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 15 * 1024 * 1024) {
        alert('حجم الصورة كبير، يرجى اختيار صورة أقل من 15 ميجابايت');
        return;
      }
      const reader = new FileReader();
      reader.onload = (event) => {
        if (event.target?.result) {
          onChange({
            backgroundImage: event.target.result as string,
          });
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    const file = e.dataTransfer.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        if (event.target?.result) {
          onChange({
            backgroundImage: event.target.result as string,
          });
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSelectPreset = (presetSvg: string) => {
    onChange({ backgroundImage: presetSvg });
  };

  const handleClearBackground = () => {
    onChange({ backgroundImage: null });
  };

  return (
    <div className="p-4 md:p-5 rounded-2xl bg-neutral-900/60 border border-neutral-800 space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-2.5 h-2.5 rounded-full bg-emerald-400 ring-4 ring-emerald-400/20" />
          <h3 className="font-bold text-base text-neutral-100">
            صورة خلفية البوستر مع أدوات التحكم
          </h3>
        </div>
        <span className="text-xs text-neutral-400">
          تعتيم • تمويه • طبقة داكنة
        </span>
      </div>

      <input
        ref={fileInputRef}
        type="file"
        accept="image/png,image/jpeg,image/webp"
        onChange={handleFileUpload}
        className="hidden"
      />

      {/* Preset background themes */}
      <div>
        <label className="block text-xs font-semibold text-neutral-300 mb-2 flex items-center gap-1.5">
          <Sparkles className="w-3.5 h-3.5 text-amber-400" />
          <span>خلفيات ملاعب وأجواء جاهزة:</span>
        </label>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
          {PRESET_BACKGROUNDS.map((bg) => {
            const isCurrent = data.backgroundImage === bg.preview;
            return (
              <button
                key={bg.id}
                type="button"
                onClick={() => handleSelectPreset(bg.preview)}
                className={`relative h-20 rounded-xl overflow-hidden border p-1 text-right transition-all cursor-pointer group ${
                  isCurrent
                    ? 'border-emerald-500 ring-2 ring-emerald-500/40 shadow-md shadow-emerald-950'
                    : 'border-neutral-800 hover:border-neutral-700'
                }`}
              >
                <img
                  src={bg.preview}
                  alt={bg.name}
                  className="absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition-transform"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/30 to-transparent" />
                <span className="absolute bottom-1.5 right-1.5 left-1.5 text-[10px] font-bold text-white leading-tight">
                  {bg.name}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Upload Custom Background Dropzone */}
      {data.backgroundImage ? (
        <div className="space-y-4 pt-1">
          {/* Preview Box */}
          <div className="relative rounded-xl overflow-hidden border border-neutral-700 h-40 bg-neutral-950 group">
            <img
              src={data.backgroundImage}
              alt="معاينة الخلفية"
              className="w-full h-full object-cover"
              style={{
                filter: data.backgroundBlur > 0 ? `blur(${data.backgroundBlur}px)` : undefined,
                opacity: data.backgroundOpacity / 100,
              }}
            />
            {/* Live Scrim in Preview */}
            <div
              className={`absolute inset-0 ${
                data.backgroundOverlayColor === 'green'
                  ? 'bg-[#02180d]'
                  : data.backgroundOverlayColor === 'navy'
                  ? 'bg-[#020b18]'
                  : 'bg-black'
              }`}
              style={{ opacity: data.backgroundDarkOverlay / 100 }}
            />
            {/* Top Tag */}
            <div className="absolute top-2 right-2 px-2.5 py-1 rounded-md bg-black/75 text-[10px] text-emerald-400 font-bold backdrop-blur-sm">
              معاينة تأثير الخلفية المباشر
            </div>

            {/* Hover Actions */}
            <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-3">
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="px-3 py-1.5 rounded-lg bg-white/95 text-neutral-900 text-xs font-bold hover:bg-white flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                <Upload className="w-3.5 h-3.5" />
                <span>استبدال الصورة</span>
              </button>
              <button
                type="button"
                onClick={handleClearBackground}
                className="px-3 py-1.5 rounded-lg bg-rose-600 text-white text-xs font-bold hover:bg-rose-500 flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>إزالة الخلفية</span>
              </button>
            </div>
          </div>

          {/* Controls: Opacity, Blur, Dark Overlay, and Overlay Color */}
          <div className="bg-neutral-950/80 p-4 rounded-xl border border-neutral-800 space-y-4">
            <div className="flex items-center gap-2 text-xs font-bold text-neutral-200 border-b border-neutral-800 pb-2">
              <SlidersHorizontal className="w-4 h-4 text-emerald-400" />
              <span>أدوات الضبط والتحكم بالصورة</span>
            </div>

            {/* 1. Opacity Slider */}
            <div>
              <div className="flex items-center justify-between text-xs text-neutral-300 mb-1.5">
                <span className="font-semibold">التعتيم / الشفافية (Opacity)</span>
                <span className="font-mono text-emerald-400 font-bold">
                  {data.backgroundOpacity}%
                </span>
              </div>
              <input
                type="range"
                min="10"
                max="100"
                value={data.backgroundOpacity}
                onChange={(e) =>
                  onChange({ backgroundOpacity: Number(e.target.value) })
                }
                className="w-full accent-emerald-500 cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-neutral-400 mt-0.5">
                <span>شفاف وخافت (10%)</span>
                <span>كامل الوضوح (100%)</span>
              </div>
            </div>

            {/* 2. Blur Slider */}
            <div>
              <div className="flex items-center justify-between text-xs text-neutral-300 mb-1.5">
                <span className="font-semibold">التمويه السينمائي (Blur)</span>
                <span className="font-mono text-amber-400 font-bold">
                  {data.backgroundBlur}px
                </span>
              </div>
              <input
                type="range"
                min="0"
                max="25"
                step="1"
                value={data.backgroundBlur}
                onChange={(e) =>
                  onChange({ backgroundBlur: Number(e.target.value) })
                }
                className="w-full accent-amber-500 cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-neutral-400 mt-0.5">
                <span>حادة بدون تمويه (0px)</span>
                <span>تمويه عميق لعزل النتيجة (25px)</span>
              </div>
            </div>

            {/* 3. Dark Overlay Scrim Slider */}
            <div>
              <div className="flex items-center justify-between text-xs text-neutral-300 mb-1.5">
                <span className="font-semibold">تركيب طبقة داكنة (Dark Overlay)</span>
                <span className="font-mono text-emerald-400 font-bold">
                  {data.backgroundDarkOverlay}%
                </span>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                value={data.backgroundDarkOverlay}
                onChange={(e) =>
                  onChange({ backgroundDarkOverlay: Number(e.target.value) })
                }
                className="w-full accent-emerald-500 cursor-pointer"
              />
              <p className="text-[11px] text-neutral-400 mt-1">
                تزيد من قتامة الخلفية لضمان قراءة النتيجة والأسماء وشعارات الفريقين بأقصى درجات الوضوح.
              </p>
            </div>

            {/* 4. Overlay Color Choice */}
            <div>
              <label className="block text-xs font-semibold text-neutral-300 mb-2 flex items-center gap-1.5">
                <Layers className="w-3.5 h-3.5 text-neutral-400" />
                <span>لون طابع الطبقة الداكنة:</span>
              </label>
              <div className="grid grid-cols-3 gap-2">
                <button
                  type="button"
                  onClick={() => onChange({ backgroundOverlayColor: 'black' })}
                  className={`py-1.5 px-2.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                    (!data.backgroundOverlayColor || data.backgroundOverlayColor === 'black')
                      ? 'bg-neutral-800 text-white border-2 border-emerald-500'
                      : 'bg-neutral-900 text-neutral-400 border border-neutral-800 hover:text-white'
                  }`}
                >
                  أسود كلاسيكي
                </button>
                <button
                  type="button"
                  onClick={() => onChange({ backgroundOverlayColor: 'green' })}
                  className={`py-1.5 px-2.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                    data.backgroundOverlayColor === 'green'
                      ? 'bg-emerald-950 text-emerald-300 border-2 border-emerald-500'
                      : 'bg-neutral-900 text-neutral-400 border border-neutral-800 hover:text-white'
                  }`}
                >
                  أخضر ديرب نجم
                </button>
                <button
                  type="button"
                  onClick={() => onChange({ backgroundOverlayColor: 'navy' })}
                  className={`py-1.5 px-2.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                    data.backgroundOverlayColor === 'navy'
                      ? 'bg-blue-950 text-blue-300 border-2 border-blue-500'
                      : 'bg-neutral-900 text-neutral-400 border border-neutral-800 hover:text-white'
                  }`}
                >
                  كحلي ليلي
                </button>
              </div>
            </div>
          </div>
        </div>
      ) : (
        <div
          onDragOver={(e) => e.preventDefault()}
          onDrop={handleDrop}
          onClick={() => fileInputRef.current?.click()}
          className="border-2 border-dashed border-neutral-700 hover:border-emerald-500/80 rounded-xl p-7 text-center cursor-pointer transition-all bg-neutral-950/40 hover:bg-emerald-950/10 group"
        >
          <div className="w-12 h-12 rounded-full bg-neutral-800 group-hover:bg-emerald-900/40 flex items-center justify-center mx-auto mb-3 text-neutral-400 group-hover:text-emerald-400 transition-colors">
            <Upload className="w-6 h-6" />
          </div>
          <p className="text-sm font-bold text-neutral-100 mb-1">
            إدراج صورة مخصصة في خلفية البوستر
          </p>
          <p className="text-xs text-neutral-400">
            انقر لرفع صورة من جهازك أو اسحبها وأفلتها هنا (PNG, JPG, WEBP)
          </p>
          <div className="mt-3 inline-flex items-center gap-1.5 text-[11px] text-emerald-400 bg-emerald-950/60 px-2.5 py-1 rounded-full border border-emerald-500/30">
            <span>ستتوفر لك فوراً أدوات ضبط التعتيم والتمويه والطبقة الداكنة</span>
          </div>
        </div>
      )}
    </div>
  );
};
