import React from 'react';
import { MatchData } from '../../types';
import { Calendar, MapPin, Trophy, Sparkles } from 'lucide-react';

interface MatchDetailsProps {
  data: MatchData;
  onChange: (updated: Partial<MatchData>) => void;
}

export const MatchDetails: React.FC<MatchDetailsProps> = ({ data, onChange }) => {
  const setTodayDate = () => {
    const today = new Date();
    const options: Intl.DateTimeFormatOptions = {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    };
    const formatted = today.toLocaleDateString('ar-EG', options);
    onChange({ date: formatted });
  };

  const HEADLINE_OPTIONS = [
    'نِهَايَةُ الْمُبَارَاةِ',
    'صَافِرَةُ النِّهَايَةِ',
    'انْتِهَاءُ الْمُبَارَاةِ',
    'فَوْزُ نَادِي دَيْرَب نَجْم',
    'نَتِيجَةُ اللِّقَاءِ',
  ];

  const TOURNAMENT_PRESETS = [
    'دوري القسم الثاني ب',
    'دوري القسم الثالث',
    'كأس مصر',
    'مباراة ودية',
    'دوري منطقة الشرقية',
  ];

  return (
    <div className="p-4 md:p-5 rounded-2xl bg-neutral-900/60 border border-neutral-800 space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-2.5 h-2.5 rounded-full bg-amber-400 ring-4 ring-amber-400/20" />
          <h3 className="font-bold text-base text-neutral-100">معلومات المباراة</h3>
        </div>
      </div>

      <div className="space-y-4">
        {/* Headline / Title */}
        <div>
          <label className="block text-xs font-semibold text-neutral-300 mb-1.5">
            عنوان التصميم الرئيسي
          </label>
          <div className="flex flex-col sm:flex-row gap-2">
            <input
              type="text"
              value={data.headline}
              onChange={(e) => onChange({ headline: e.target.value })}
              placeholder="نِهَايَةُ الْمُبَارَاةِ"
              className="flex-1 bg-neutral-950/80 border border-neutral-700/80 focus:border-emerald-500 rounded-xl px-3.5 py-2.5 text-sm text-white outline-none"
            />
          </div>
          {/* Quick headline suggestions */}
          <div className="flex flex-wrap gap-1.5 mt-2">
            {HEADLINE_OPTIONS.map((opt) => (
              <button
                key={opt}
                type="button"
                onClick={() => onChange({ headline: opt })}
                className={`text-[11px] px-2.5 py-1 rounded-md transition-colors ${
                  data.headline === opt
                    ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                    : 'bg-neutral-800 text-neutral-400 hover:text-neutral-200'
                }`}
              >
                {opt}
              </button>
            ))}
          </div>
        </div>

        {/* Tournament & Round */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <label className="block text-xs font-semibold text-neutral-300 mb-1.5 flex items-center gap-1.5">
              <Trophy className="w-3.5 h-3.5 text-amber-400" />
              <span>البطولة (اختياري)</span>
            </label>
            <input
              type="text"
              value={data.tournament}
              onChange={(e) => onChange({ tournament: e.target.value })}
              placeholder="مثال: دوري القسم الثاني ب"
              className="w-full bg-neutral-950/80 border border-neutral-700/80 focus:border-emerald-500 rounded-xl px-3.5 py-2 text-sm text-white outline-none"
            />
            {/* Quick tournament pills */}
            <div className="flex flex-wrap gap-1 mt-1.5">
              {TOURNAMENT_PRESETS.slice(0, 3).map((tour) => (
                <button
                  key={tour}
                  type="button"
                  onClick={() => onChange({ tournament: tour })}
                  className="text-[10px] text-neutral-400 hover:text-white bg-neutral-800/80 hover:bg-neutral-800 px-2 py-0.5 rounded"
                >
                  {tour}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-neutral-300 mb-1.5">
              الجولة أو الدور (اختياري)
            </label>
            <input
              type="text"
              value={data.round}
              onChange={(e) => onChange({ round: e.target.value })}
              placeholder="مثال: الجولة 14 أو دور الـ 32"
              className="w-full bg-neutral-950/80 border border-neutral-700/80 focus:border-emerald-500 rounded-xl px-3.5 py-2 text-sm text-white outline-none"
            />
          </div>
        </div>

        {/* Stadium */}
        <div>
          <label className="block text-xs font-semibold text-neutral-300 mb-1.5 flex items-center gap-1.5">
            <MapPin className="w-3.5 h-3.5 text-emerald-400" />
            <span>الملعب</span>
          </label>
          <input
            type="text"
            value={data.stadium}
            onChange={(e) => onChange({ stadium: e.target.value })}
            placeholder="استاد ديرب نجم الرياضي"
            className="w-full bg-neutral-950/80 border border-neutral-700/80 focus:border-emerald-500 rounded-xl px-3.5 py-2 text-sm text-white outline-none"
          />
        </div>

        {/* Date & Time */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-semibold text-neutral-300 flex items-center gap-1.5">
                <Calendar className="w-3.5 h-3.5 text-emerald-400" />
                <span>تاريخ المباراة</span>
              </label>
              <button
                type="button"
                onClick={setTodayDate}
                className="text-[11px] text-emerald-400 hover:text-emerald-300 underline font-medium"
              >
                اليوم
              </button>
            </div>
            <input
              type="text"
              value={data.date}
              onChange={(e) => onChange({ date: e.target.value })}
              placeholder="الخميس 15 أكتوبر 2026"
              className="w-full bg-neutral-950/80 border border-neutral-700/80 focus:border-emerald-500 rounded-xl px-3.5 py-2 text-sm text-white outline-none"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-neutral-300 mb-1.5">
              وقت المباراة (اختياري)
            </label>
            <input
              type="text"
              value={data.time}
              onChange={(e) => onChange({ time: e.target.value })}
              placeholder="04:30 م"
              className="w-full bg-neutral-950/80 border border-neutral-700/80 focus:border-emerald-500 rounded-xl px-3.5 py-2 text-sm text-white outline-none"
            />
          </div>
        </div>
      </div>
    </div>
  );
};
