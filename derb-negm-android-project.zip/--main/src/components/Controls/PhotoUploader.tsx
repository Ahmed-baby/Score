import React, { useRef } from 'react';
import { Upload, Image as ImageIcon, Trash2, Eye } from 'lucide-react';

interface PhotoUploaderProps {
  photo: string | null;
  opacity: number;
  onPhotoChange: (photo: string | null) => void;
  onOpacityChange: (opacity: number) => void;
}

export const PhotoUploader: React.FC<PhotoUploaderProps> = ({
  photo,
  opacity,
  onPhotoChange,
  onOpacityChange,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 12 * 1024 * 1024) {
        alert('حجم الصورة كبير جداً، يرجى اختيار صورة أقل من 12 ميجابايت');
        return;
      }
      const reader = new FileReader();
      reader.onload = (event) => {
        if (event.target?.result) {
          onPhotoChange(event.target.result as string);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    const file = e.dataTransfer.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        if (event.target?.result) {
          onPhotoChange(event.target.result as string);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="p-4 md:p-5 rounded-2xl bg-neutral-900/60 border border-neutral-800 space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-2.5 h-2.5 rounded-full bg-emerald-400 ring-4 ring-emerald-400/20" />
          <h3 className="font-bold text-base text-neutral-100">
            صورة المباراة (اختيارية)
          </h3>
        </div>
        <span className="text-xs text-neutral-400">
          PNG, JPG, JPEG, WEBP
        </span>
      </div>

      <input
        ref={fileInputRef}
        type="file"
        accept="image/png,image/jpeg,image/webp"
        onChange={handleFileUpload}
        className="hidden"
      />

      {photo ? (
        <div className="space-y-4">
          <div className="relative rounded-xl overflow-hidden border border-neutral-700 h-40 bg-neutral-950 group">
            <img
              src={photo}
              alt="معاينة صورة المباراة"
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-3">
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="px-3 py-1.5 rounded-lg bg-white/90 text-neutral-900 text-xs font-bold hover:bg-white flex items-center gap-1.5 transition-colors"
              >
                <Upload className="w-3.5 h-3.5" />
                <span>استبدال الصورة</span>
              </button>
              <button
                type="button"
                onClick={() => onPhotoChange(null)}
                className="px-3 py-1.5 rounded-lg bg-rose-600 text-white text-xs font-bold hover:bg-rose-500 flex items-center gap-1.5 transition-colors"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>حذف الصورة</span>
              </button>
            </div>
          </div>

          {/* Opacity Control */}
          <div>
            <div className="flex items-center justify-between text-xs text-neutral-300 mb-1.5">
              <span>تعتيم طبقة الخلفية (Scrim Darkening)</span>
              <span className="font-mono text-emerald-400">{opacity}%</span>
            </div>
            <input
              type="range"
              min="20"
              max="100"
              value={opacity}
              onChange={(e) => onOpacityChange(Number(e.target.value))}
              className="w-full accent-emerald-500 cursor-pointer"
            />
            <p className="text-[11px] text-neutral-500 mt-1">
              زيادة النسبة تزيد من سواد الطبقة فوق الصورة لضمان قراءة الأرقام والنصوص بوضوح تام.
            </p>
          </div>
        </div>
      ) : (
        <div
          onDragOver={(e) => e.preventDefault()}
          onDrop={handleDrop}
          onClick={() => fileInputRef.current?.click()}
          className="border-2 border-dashed border-neutral-700 hover:border-emerald-500/80 rounded-xl p-6 text-center cursor-pointer transition-all bg-neutral-950/40 hover:bg-emerald-950/10 group"
        >
          <div className="w-12 h-12 rounded-full bg-neutral-800 group-hover:bg-emerald-900/40 flex items-center justify-center mx-auto mb-3 text-neutral-400 group-hover:text-emerald-400 transition-colors">
            <ImageIcon className="w-6 h-6" />
          </div>
          <p className="text-sm font-semibold text-neutral-200 mb-1">
            انقر لرفع صورة من المباراة أو اسحب وأفلت هنا
          </p>
          <p className="text-xs text-neutral-400">
            يمكنك تركها فارغة، وسيعمل التصميم تلقائياً مع خلفية النادي الرياضية
          </p>
        </div>
      )}
    </div>
  );
};
