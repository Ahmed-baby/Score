import React from 'react';
import { Download, RefreshCw, ArrowLeftRight, Sparkles } from 'lucide-react';
import { DERB_NEGM_LOGO } from '../data/defaultAssets';

interface HeaderProps {
  onExport: () => void;
  onReset: () => void;
  onSwapTeams: () => void;
  isExporting: boolean;
  isSavedLocally?: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  onExport,
  onReset,
  onSwapTeams,
  isExporting,
  isSavedLocally = false,
}) => {
  return (
    <header className="sticky top-0 z-40 bg-neutral-950/90 backdrop-blur-md border-b border-neutral-800 px-4 lg:px-8 py-3">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
        {/* Zone 1: Brand Wordmark */}
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-950/80 border border-emerald-500/40 p-1 flex items-center justify-center shrink-0 shadow-sm shadow-emerald-950">
            <img
              src={DERB_NEGM_LOGO}
              alt="نادي ديرب نجم"
              className="w-full h-full object-contain"
            />
          </div>
          <div className="flex flex-col">
            <span
              style={{ fontFamily: 'var(--font-changa), sans-serif' }}
              className="text-lg font-black tracking-tight text-white leading-tight"
            >
              استوديو نتائج المباريات
            </span>
            <span className="text-[11px] text-emerald-400 font-semibold">
              نادي ديرب نجم الرياضي
            </span>
          </div>
        </div>

        {/* Zone 2: Fast Action Utilities & Auto-save status */}
        <div className="hidden sm:flex items-center gap-2 text-xs">
          {/* LocalStorage Auto-save badge */}
          <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-neutral-900 border border-neutral-800 text-[11px] text-neutral-400">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
            <span className="text-neutral-300 font-medium">حفظ تلقائي بالمتصفح</span>
          </div>

          <button
            type="button"
            onClick={onSwapTeams}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-neutral-900 hover:bg-neutral-800 text-neutral-300 hover:text-white border border-neutral-800 transition-colors font-medium cursor-pointer"
            title="تبديل الفريقين الأول والمنافس"
          >
            <ArrowLeftRight className="w-3.5 h-3.5 text-emerald-400" />
            <span>تبديل الفريقين</span>
          </button>

          <button
            type="button"
            onClick={onReset}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-neutral-900 hover:bg-neutral-800 text-neutral-400 hover:text-rose-400 border border-neutral-800 transition-colors font-medium cursor-pointer"
            title="إعادة ضبط القيم الافتراضية ومسح التخزين المحلي"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>إعادة ضبط</span>
          </button>
        </div>

        {/* Zone 3: Primary Action (Download Poster) */}
        <div className="flex items-center gap-2">
          {/* Mobile swap button */}
          <button
            type="button"
            onClick={onSwapTeams}
            className="sm:hidden p-2 rounded-lg bg-neutral-900 text-neutral-300 border border-neutral-800"
            title="تبديل الفريقين"
          >
            <ArrowLeftRight className="w-4 h-4 text-emerald-400" />
          </button>

          <button
            type="button"
            onClick={onExport}
            disabled={isExporting}
            className="inline-flex items-center gap-2 px-4 py-2 sm:px-5 sm:py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 via-emerald-500 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold text-xs sm:text-sm shadow-lg shadow-emerald-900/40 hover:shadow-emerald-900/60 active:scale-95 transition-all disabled:opacity-50 cursor-pointer"
          >
            {isExporting ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin" />
                <span>جاري استخراج البوستر...</span>
              </>
            ) : (
              <>
                <Download className="w-4 h-4" />
                <span>تحميل التصميم (1080×1350)</span>
              </>
            )}
          </button>
        </div>
      </div>
    </header>
  );
};
