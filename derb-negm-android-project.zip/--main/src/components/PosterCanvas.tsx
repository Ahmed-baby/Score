import React, { forwardRef } from 'react';
import { MatchData } from '../types';
import { Calendar, MapPin, Trophy, Shield } from 'lucide-react';
import { DEFAULT_STADIUM_BG } from '../data/defaultAssets';

interface PosterCanvasProps {
  data: MatchData;
  scale?: number; // Optional scaling factor if needed
  className?: string;
}

export const PosterCanvas = forwardRef<HTMLDivElement, PosterCanvasProps>(
  ({ data, className = '' }, ref) => {
    const {
      team1,
      team2,
      headline,
      subheadline,
      date,
      time,
      stadium,
      tournament,
      round,
      matchPhoto,
      matchPhotoOpacity,
      backgroundImage,
      backgroundOpacity = 80,
      backgroundBlur = 0,
      backgroundDarkOverlay = 65,
      backgroundOverlayColor = 'black',
      scorersTeam1,
      scorersTeam2,
      showScorers,
      extraInfo,
      template,
    } = data;

    // Determine template-specific styles
    const isLight = template === 'modern-light';
    const isPhotoFocus = template === 'match-photo';
    const isNeon = template === 'stadium-neon';
    const isGold = template === 'classic-gold';

    return (
      <div
        ref={ref}
        id="match-poster-export-node"
        style={{ width: '1080px', height: '1350px' }}
        className={`relative overflow-hidden select-none flex flex-col justify-between text-right ${className} ${
          isLight
            ? 'bg-neutral-50 text-neutral-900'
            : 'bg-[#03150c] text-white'
        }`}
        dir="rtl"
      >
        {/* ================= BACKGROUND LAYERS ================= */}
        {/* Template 1: Dark Professional */}
        {template === 'dark-pro' && (
          <div className="absolute inset-0 pointer-events-none">
            {/* Base SVG Stadium lighting */}
            <img
              src={DEFAULT_STADIUM_BG}
              alt=""
              className="absolute inset-0 w-full h-full object-cover opacity-90"
            />
            {/* Diagonal Athletic Angled Cuts */}
            <div
              className="absolute -top-40 -right-40 w-[600px] h-[600px] rounded-full blur-[120px] opacity-25 pointer-events-none"
              style={{ background: '#10b981' }}
            />
            <div
              className="absolute -bottom-20 -left-20 w-[550px] h-[550px] rounded-full blur-[100px] opacity-25 pointer-events-none"
              style={{ background: '#d4af37' }}
            />
            {/* Subtle carbon diagonal grid */}
            <div
              className="absolute inset-0 opacity-[0.035]"
              style={{
                backgroundImage:
                  'radial-gradient(circle at 1px 1px, #fff 1px, transparent 0)',
                backgroundSize: '36px 36px',
              }}
            />
          </div>
        )}

        {/* Template 2: Modern Light */}
        {isLight && (
          <div className="absolute inset-0 pointer-events-none">
            {/* Clean subtle light pitch stripes */}
            <div
              className="absolute inset-0 opacity-[0.04]"
              style={{
                backgroundImage:
                  'linear-gradient(90deg, #047857 50%, transparent 50%)',
                backgroundSize: '120px 100%',
              }}
            />
            {/* Top Emerald Gradient Header Ribbon */}
            <div className="absolute top-0 inset-x-0 h-8 bg-gradient-to-r from-[#063a1f] via-[#10b981] to-[#063a1f]" />
            {/* Subtle soft center radial glow */}
            <div
              className="absolute top-1/3 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] rounded-full opacity-15"
              style={{
                background:
                  'radial-gradient(circle, #34d399 0%, transparent 70%)',
              }}
            />
            {/* Gold bottom accent line */}
            <div className="absolute bottom-0 inset-x-0 h-3 bg-gradient-to-r from-[#d4af37] via-[#f59e0b] to-[#d4af37]" />
          </div>
        )}

        {/* Template 3: Match Photo */}
        {isPhotoFocus && (
          <div className="absolute inset-0 pointer-events-none">
            {matchPhoto ? (
              <>
                <img
                  src={matchPhoto}
                  alt="Match action"
                  className="absolute inset-0 w-full h-full object-cover"
                />
                {/* Powerful multi-stop dark scrim to guarantee 100% typography contrast */}
                <div
                  className="absolute inset-0 bg-gradient-to-b from-[#02130a]/90 via-[#031d10]/85 to-[#010b06]/98"
                  style={{ opacity: matchPhotoOpacity / 100 }}
                />
              </>
            ) : (
              <>
                <img
                  src={DEFAULT_STADIUM_BG}
                  alt=""
                  className="absolute inset-0 w-full h-full object-cover opacity-80"
                />
                <div className="absolute inset-0 bg-gradient-to-b from-[#042013]/90 via-[#02120b]/80 to-[#000000]/95" />
              </>
            )}
            {/* Top gold bar */}
            <div className="absolute top-0 inset-x-0 h-4 bg-gradient-to-r from-transparent via-[#d4af37] to-transparent" />
          </div>
        )}

        {/* Template 4: Stadium Neon */}
        {isNeon && (
          <div className="absolute inset-0 pointer-events-none bg-[#020d07]">
            <img
              src={DEFAULT_STADIUM_BG}
              alt=""
              className="absolute inset-0 w-full h-full object-cover opacity-60 mix-blend-screen"
            />
            {/* Dual neon edge lighting */}
            <div className="absolute -top-32 left-1/4 w-[500px] h-[500px] rounded-full blur-[140px] bg-emerald-500/30" />
            <div className="absolute top-1/2 -right-32 w-[500px] h-[500px] rounded-full blur-[140px] bg-amber-400/25" />
            <div className="absolute inset-0 border-[16px] border-emerald-950/40 m-6 rounded-3xl pointer-events-none" />
            <div className="absolute inset-0 border border-emerald-500/30 m-8 rounded-2xl pointer-events-none" />
          </div>
        )}

        {/* Template 5: Classic Gold */}
        {isGold && (
          <div className="absolute inset-0 pointer-events-none bg-[#041a0e]">
            {/* Elegant double border frame */}
            <div className="absolute inset-8 border-2 border-[#d4af37]/60 pointer-events-none" />
            <div className="absolute inset-10 border border-[#d4af37]/30 pointer-events-none" />
            {/* Corner geometric ornaments */}
            <div className="absolute top-7 right-7 w-7 h-7 border-t-4 border-r-4 border-[#d4af37]" />
            <div className="absolute top-7 left-7 w-7 h-7 border-t-4 border-l-4 border-[#d4af37]" />
            <div className="absolute bottom-7 right-7 w-7 h-7 border-b-4 border-r-4 border-[#d4af37]" />
            <div className="absolute bottom-7 left-7 w-7 h-7 border-b-4 border-l-4 border-[#d4af37]" />
            <div
              className="absolute inset-0 opacity-[0.03]"
              style={{
                backgroundImage:
                  'radial-gradient(circle, #d4af37 1px, transparent 1px)',
                backgroundSize: '24px 24px',
              }}
            />
          </div>
        )}

        {/* Custom Poster Background Image (صورة في الخلفية) */}
        {backgroundImage && (
          <div className="absolute inset-0 pointer-events-none overflow-hidden z-0">
            <img
              src={backgroundImage}
              alt="Custom Poster Background"
              className="w-full h-full object-cover"
              style={{
                filter: backgroundBlur > 0 ? `blur(${backgroundBlur}px)` : undefined,
                opacity: backgroundOpacity / 100,
                transform: backgroundBlur > 0 ? 'scale(1.08)' : undefined,
              }}
            />
            {/* Dark Scrim overlay to guarantee text and score legibility */}
            <div
              className={`absolute inset-0 ${
                isLight
                  ? 'bg-white'
                  : backgroundOverlayColor === 'green'
                  ? 'bg-[#02180d]'
                  : backgroundOverlayColor === 'navy'
                  ? 'bg-[#020b18]'
                  : backgroundOverlayColor === 'vignette'
                  ? 'bg-black'
                  : 'bg-black'
              }`}
              style={{ opacity: backgroundDarkOverlay / 100 }}
            />
          </div>
        )}

        {/* Optional Match Photo in other templates (if uploaded and not match-photo template) */}
        {!isPhotoFocus && matchPhoto && !backgroundImage && (
          <div className="absolute inset-0 pointer-events-none overflow-hidden z-0">
            <img
              src={matchPhoto}
              alt="Match background"
              className="w-full h-full object-cover"
              style={{ opacity: (matchPhotoOpacity / 100) * 0.28 }}
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#02130a] via-transparent to-[#02130a]/80" />
          </div>
        )}

        {/* ================= CONTENT CONTAINER ================= */}
        <div className="relative z-10 flex flex-col justify-between h-full p-16">
          {/* TOP SECTION: Header & Tournament */}
          <div className="flex flex-col items-center text-center pt-2">
            {/* Tournament & Round Tag */}
            {(tournament || round) && (
              <div
                className={`inline-flex items-center gap-3 px-6 py-2.5 rounded-full mb-6 font-semibold text-lg tracking-wide ${
                  isLight
                    ? 'bg-emerald-100/90 text-emerald-900 border border-emerald-300/60 shadow-sm'
                    : 'bg-emerald-950/80 text-emerald-300 border border-emerald-500/30 backdrop-blur-md shadow-lg shadow-black/40'
                }`}
              >
                <Trophy
                  className={`w-5 h-5 ${isLight ? 'text-emerald-700' : 'text-[#d4af37]'}`}
                />
                <span className="font-bold">{tournament}</span>
                {tournament && round && (
                  <span
                    className={
                      isLight ? 'text-emerald-500' : 'text-emerald-400'
                    }
                  >
                    •
                  </span>
                )}
                {round && <span>{round}</span>}
              </div>
            )}

            {/* Main Headline: نِهَايَةُ الْمُبَارَاةِ */}
            <div className="relative">
              <h1
                style={{ fontFamily: 'var(--font-changa), var(--font-cairo), sans-serif' }}
                className={`text-6xl md:text-7xl font-black tracking-tight drop-shadow-md ${
                  isLight
                    ? 'text-neutral-900'
                    : 'text-transparent bg-clip-text bg-gradient-to-b from-white via-neutral-100 to-emerald-200'
                }`}
              >
                {headline || 'نِهَايَةُ الْمُبَارَاةِ'}
              </h1>

              {/* Sub-golden accent line */}
              <div className="flex items-center justify-center gap-4 mt-4">
                <div
                  className={`h-[2px] w-24 rounded-full ${
                    isLight
                      ? 'bg-gradient-to-l from-[#d4af37] to-transparent'
                      : 'bg-gradient-to-l from-[#d4af37] to-transparent'
                  }`}
                />
                <div className="w-2.5 h-2.5 rotate-45 bg-[#d4af37] shadow-sm shadow-[#d4af37]/50" />
                <div
                  className={`h-[2px] w-24 rounded-full ${
                    isLight
                      ? 'bg-gradient-to-r from-[#d4af37] to-transparent'
                      : 'bg-gradient-to-r from-[#d4af37] to-transparent'
                  }`}
                />
              </div>
            </div>
          </div>

          {/* MIDDLE SECTION: TEAMS & MASSIVE SCORE */}
          <div className="my-auto py-6">
            <div className="grid grid-cols-12 items-center gap-4">
              {/* TEAM 1 (Right in RTL / First Team - default Derb Negm) */}
              <div className="col-span-4 flex flex-col items-center text-center">
                {/* Logo Frame */}
                <div className="relative group">
                  {/* Subtle rim halo */}
                  <div
                    className={`absolute -inset-3 rounded-full blur-xl opacity-60 pointer-events-none ${
                      isLight ? 'bg-emerald-400/30' : 'bg-emerald-500/25'
                    }`}
                  />
                  <div
                    className={`relative w-44 h-44 rounded-3xl p-4 flex items-center justify-center transition-all ${
                      isLight
                        ? 'bg-white shadow-xl shadow-emerald-950/10 border-2 border-emerald-100'
                        : 'bg-gradient-to-b from-emerald-950/60 to-black/80 border-2 border-emerald-500/40 shadow-2xl shadow-black/80 backdrop-blur-sm'
                    }`}
                  >
                    {team1.logo ? (
                      <img
                        src={team1.logo}
                        alt={team1.name}
                        className="max-w-full max-h-full object-contain filter drop-shadow-md"
                      />
                    ) : (
                      <Shield className="w-20 h-20 text-emerald-500 opacity-60" />
                    )}
                  </div>
                </div>

                {/* Team 1 Name */}
                <h2
                  style={{ fontFamily: 'var(--font-cairo), sans-serif' }}
                  className={`mt-6 text-3xl font-extrabold max-w-[260px] leading-tight ${
                    isLight ? 'text-emerald-950' : 'text-white'
                  }`}
                >
                  {team1.name || 'نادي ديرب نجم'}
                </h2>

                {/* Penalties indicator if applicable */}
                {team1.penalties !== undefined && team1.penalties !== null && (
                  <span
                    className={`text-sm font-semibold mt-2 px-3 py-1 rounded-md ${
                      isLight
                        ? 'bg-emerald-50 text-emerald-800'
                        : 'bg-emerald-950/80 text-[#d4af37] border border-amber-500/30'
                    }`}
                  >
                    ({team1.penalties} ترجيح)
                  </span>
                )}
              </div>

              {/* SCOREBOARD CENTERPIECE */}
              <div className="col-span-4 flex flex-col items-center justify-center text-center">
                {/* Extra Match State (e.g. ركلات ترجيح أو وقت إضافي) */}
                {extraInfo && (
                  <span className="text-sm font-bold text-[#d4af37] mb-3 px-3 py-0.5 rounded-full bg-amber-950/40 border border-amber-500/30">
                    {extraInfo}
                  </span>
                )}

                {/* SCORE CONTAINER */}
                <div
                  className={`relative px-8 py-5 rounded-3xl flex items-center justify-center gap-6 ${
                    isLight
                      ? 'bg-white/95 border-2 border-emerald-200/80 shadow-2xl shadow-emerald-950/15'
                      : 'bg-gradient-to-b from-[#06301a]/90 via-[#031c10]/95 to-[#010c06]/95 border-2 border-[#d4af37]/60 shadow-[0_0_60px_rgba(4,120,87,0.35)] backdrop-blur-md'
                  }`}
                >
                  {/* Team 1 Score (RTL right) */}
                  <span
                    style={{ fontFamily: 'var(--font-changa), sans-serif' }}
                    className={`text-8xl md:text-9xl font-black tabular-nums tracking-tighter leading-none ${
                      isLight
                        ? 'text-emerald-800'
                        : 'text-transparent bg-clip-text bg-gradient-to-b from-white via-emerald-100 to-[#d4af37]'
                    }`}
                  >
                    {team1.score}
                  </span>

                  {/* Sport Dash / VS divider */}
                  <div className="flex flex-col items-center justify-center gap-2">
                    <span
                      style={{ fontFamily: 'var(--font-changa), sans-serif' }}
                      className={`text-6xl font-light ${
                        isLight ? 'text-neutral-400' : 'text-[#d4af37]'
                      }`}
                    >
                      -
                    </span>
                  </div>

                  {/* Team 2 Score (RTL left) */}
                  <span
                    style={{ fontFamily: 'var(--font-changa), sans-serif' }}
                    className={`text-8xl md:text-9xl font-black tabular-nums tracking-tighter leading-none ${
                      isLight
                        ? 'text-neutral-800'
                        : 'text-transparent bg-clip-text bg-gradient-to-b from-white via-neutral-100 to-neutral-400'
                    }`}
                  >
                    {team2.score}
                  </span>
                </div>

                {/* Subtitle: النتيجة النهائية */}
                <div
                  className={`mt-4 px-6 py-1.5 rounded-full text-base font-bold tracking-widest ${
                    isLight
                      ? 'bg-emerald-900 text-white shadow-md'
                      : 'bg-gradient-to-r from-[#d4af37] via-[#f59e0b] to-[#d4af37] text-black font-black shadow-lg shadow-amber-500/20'
                  }`}
                >
                  {subheadline || 'النتيجة النهائية'}
                </div>
              </div>

              {/* TEAM 2 (Left in RTL / Opponent Team) */}
              <div className="col-span-4 flex flex-col items-center text-center">
                {/* Logo Frame */}
                <div className="relative group">
                  <div
                    className={`absolute -inset-3 rounded-full blur-xl opacity-50 pointer-events-none ${
                      isLight ? 'bg-neutral-300/40' : 'bg-neutral-600/20'
                    }`}
                  />
                  <div
                    className={`relative w-44 h-44 rounded-3xl p-4 flex items-center justify-center transition-all ${
                      isLight
                        ? 'bg-white shadow-xl shadow-neutral-900/10 border-2 border-neutral-200'
                        : 'bg-gradient-to-b from-neutral-900/80 to-black/80 border-2 border-neutral-700/60 shadow-2xl shadow-black/80 backdrop-blur-sm'
                    }`}
                  >
                    {team2.logo ? (
                      <img
                        src={team2.logo}
                        alt={team2.name}
                        className="max-w-full max-h-full object-contain filter drop-shadow-md"
                      />
                    ) : (
                      <Shield className="w-20 h-20 text-neutral-400 opacity-60" />
                    )}
                  </div>
                </div>

                {/* Team 2 Name */}
                <h2
                  style={{ fontFamily: 'var(--font-cairo), sans-serif' }}
                  className={`mt-6 text-3xl font-extrabold max-w-[260px] leading-tight ${
                    isLight ? 'text-neutral-900' : 'text-neutral-100'
                  }`}
                >
                  {team2.name || 'الفريق المنافس'}
                </h2>

                {/* Penalties indicator if applicable */}
                {team2.penalties !== undefined && team2.penalties !== null && (
                  <span
                    className={`text-sm font-semibold mt-2 px-3 py-1 rounded-md ${
                      isLight
                        ? 'bg-neutral-100 text-neutral-800'
                        : 'bg-neutral-900 text-neutral-300 border border-neutral-700'
                    }`}
                  >
                    ({team2.penalties} ترجيح)
                  </span>
                )}
              </div>
            </div>

            {/* OPTIONAL GOAL SCORERS SECTION */}
            {showScorers && (scorersTeam1 || scorersTeam2) && (
              <div
                className={`mt-10 mx-6 p-5 rounded-2xl grid grid-cols-2 gap-8 text-sm ${
                  isLight
                    ? 'bg-emerald-50/90 border border-emerald-200/80 text-emerald-950'
                    : 'bg-black/50 border border-emerald-500/25 text-neutral-200 backdrop-blur-md'
                }`}
              >
                {/* Team 1 Scorers */}
                <div className="flex flex-col items-start border-l border-emerald-500/20 pl-4">
                  <div className="flex items-center gap-2 font-bold text-base mb-1.5 text-emerald-500">
                    <span>⚽</span>
                    <span>{team1.name}</span>
                  </div>
                  <p className="whitespace-pre-line leading-relaxed text-sm opacity-90">
                    {scorersTeam1 || '—'}
                  </p>
                </div>

                {/* Team 2 Scorers */}
                <div className="flex flex-col items-start pr-2">
                  <div className="flex items-center gap-2 font-bold text-base mb-1.5 text-neutral-400">
                    <span>⚽</span>
                    <span>{team2.name}</span>
                  </div>
                  <p className="whitespace-pre-line leading-relaxed text-sm opacity-90">
                    {scorersTeam2 || '—'}
                  </p>
                </div>
              </div>
            )}
          </div>

          {/* BOTTOM SECTION: Match Details & Venue */}
          <div className="pt-4 border-t border-emerald-500/20">
            <div
              className={`flex items-center justify-between px-6 py-4 rounded-2xl ${
                isLight
                  ? 'bg-neutral-100/90 text-neutral-800'
                  : 'bg-black/40 text-neutral-200 backdrop-blur-md border border-white/5'
              }`}
            >
              {/* Stadium */}
              <div className="flex items-center gap-3">
                <div
                  className={`p-2.5 rounded-xl ${
                    isLight
                      ? 'bg-emerald-200 text-emerald-900'
                      : 'bg-emerald-950/80 text-[#d4af37] border border-amber-500/30'
                  }`}
                >
                  <MapPin className="w-5 h-5" />
                </div>
                <div className="flex flex-col">
                  <span className="text-xs text-neutral-400 font-medium">
                    الملعب
                  </span>
                  <span className="font-bold text-lg">
                    {stadium || 'استاد ديرب نجم الرياضي'}
                  </span>
                </div>
              </div>

              {/* Official Club Branding Center */}
              <div className="hidden md:flex flex-col items-center">
                <span
                  style={{ fontFamily: 'var(--font-cairo), sans-serif' }}
                  className="text-xs tracking-wider font-extrabold uppercase text-[#d4af37]"
                >
                  نادي ديرب نجم الرياضي
                </span>
                <span className="text-[10px] text-neutral-400">
                  المركز الإعلامي الرسمي
                </span>
              </div>

              {/* Date & Time */}
              <div className="flex items-center gap-3">
                <div className="flex flex-col text-left">
                  <span className="text-xs text-neutral-400 font-medium">
                    تاريخ اللقاء
                  </span>
                  <span className="font-bold text-lg">
                    {date} {time ? `• ${time}` : ''}
                  </span>
                </div>
                <div
                  className={`p-2.5 rounded-xl ${
                    isLight
                      ? 'bg-emerald-200 text-emerald-900'
                      : 'bg-emerald-950/80 text-[#d4af37] border border-amber-500/30'
                  }`}
                >
                  <Calendar className="w-5 h-5" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
);

PosterCanvas.displayName = 'PosterCanvas';
