import { MatchData } from '../types';

export const STORAGE_KEY = 'derb_negm_football_poster_data_v2';

/**
 * Safely loads saved match data from localStorage, merging with defaults
 */
export function loadSavedMatchData(defaults: MatchData): MatchData {
  if (typeof window === 'undefined') return defaults;

  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return defaults;

    const parsed = JSON.parse(raw);
    if (!parsed || typeof parsed !== 'object') return defaults;

    // Deep merge to ensure any newly added properties exist
    return {
      ...defaults,
      ...parsed,
      team1: {
        ...defaults.team1,
        ...(parsed.team1 || {}),
      },
      team2: {
        ...defaults.team2,
        ...(parsed.team2 || {}),
      },
    };
  } catch (error) {
    console.warn('Failed to load saved match data from localStorage:', error);
    return defaults;
  }
}

/**
 * Safely saves match data to localStorage with quota protection
 */
export function saveMatchData(data: MatchData): boolean {
  if (typeof window === 'undefined') return false;

  try {
    const serialized = JSON.stringify(data);
    localStorage.setItem(STORAGE_KEY, serialized);
    return true;
  } catch (error) {
    // If quota exceeded due to large images, try saving without heavy base64 photos
    try {
      console.warn('LocalStorage full, attempting fallback save without background image:', error);
      const trimmed = {
        ...data,
        backgroundImage: null,
      };
      localStorage.setItem(STORAGE_KEY, JSON.stringify(trimmed));
      return true;
    } catch (fallbackError) {
      console.error('LocalStorage save failed:', fallbackError);
      return false;
    }
  }
}

/**
 * Clears saved match data from localStorage
 */
export function clearSavedMatchData(): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.removeItem(STORAGE_KEY);
  } catch (error) {
    console.error('Failed to clear localStorage:', error);
  }
}
