import React, { useState, useRef, useEffect } from 'react';
import { MatchData, TemplateId } from './types';
import {
  DERB_NEGM_LOGO,
  GENERIC_OPPONENT_LOGO,
} from './data/defaultAssets';
import { PosterCanvas } from './components/PosterCanvas';
import { Header } from './components/Header';
import { TeamCard } from './components/Controls/TeamCard';
import { MatchDetails } from './components/Controls/MatchDetails';
import { PhotoUploader } from './components/Controls/PhotoUploader';
import { TemplatePicker } from './components/Controls/TemplatePicker';
import { BackgroundSection } from './components/Controls/BackgroundSection';
import { ScorersSection } from './components/Controls/ScorersSection';
import { ExportModal } from './components/ExportModal';
import { loadSavedMatchData, saveMatchData, clearSavedMatchData } from './utils/storage';
import { toPng } from 'html-to-image';
import confetti from 'canvas-confetti';
import {
  Download,
  Eye,
  Settings2,
  Sparkles,
  Maximize2,
  ZoomIn,
  ZoomOut,
  RefreshCw,
  Trophy,
  Shield,
  Layers,
} from 'lucide-react';

const INITIAL_MATCH_DATA: MatchData = {
  team1: {
    name: 'نادي ديرب نجم',
    logo: DERB_NEGM_LOGO,
    score: 2,
    penalties: null,
    shortName: 'ديرب نجم',
  },
  team2: {
    name: 'الفريق المنافس',
    logo: GENERIC_OPPONENT_LOGO,
    score: 1,
    penalties: null,
    shortName: 'المنافس',
  },
  headline: 'نِهَايَةُ الْمُبَارَاةِ',
  subheadline: 'النتيجة النهائية',
  date: 'الخميس 15 أكتوبر 2026',
  time: '04:30 م',
  stadium: 'استاد ديرب نجم الرياضي',
  tournament: 'دوري القسم الثاني ب',
  round: 'الجولة 14',
  matchPhoto: null,
  matchPhotoOpacity: 85,
  backgroundImage: null,
  backgroundOpacity: 80,
  backgroundBlur: 0,
  backgroundDarkOverlay: 65,
  scorersTeam1: 'محمد إبراهيم 34\' • أحمد زكي 79\'',
  scorersTeam2: 'محمود سالم 62\'',
  showScorers: false,
  extraInfo: '',
  template: 'dark-pro',
};

export default function App() {
  const [matchData, setMatchData] = useState<MatchData>(() => {
    return loadSavedMatchData(INITIAL_MATCH_DATA);
  });
  const [isSavedLocally, setIsSavedLocally] = useState(false);
  const [mobileTab, setMobileTab] = useState<'editor' | 'preview'>('editor');
  const [isExporting, setIsExporting] = useState(false);
  const [exportedImageUrl, setExportedImageUrl] = useState<string | null>(null);
  const [exportedFileName, setExportedFileName] = useState<string>('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [previewScale, setPreviewScale] = useState<number>(0.38); // Auto scaled for preview box
  const [activeControlTab, setActiveControlTab] = useState<'teams' | 'background' | 'match' | 'template' | 'photo' | 'scorers'>('teams');

  const previewContainerRef = useRef<HTMLDivElement>(null);
  const exportNodeRef = useRef<HTMLDivElement>(null);

  // Auto-save to LocalStorage whenever matchData changes
  useEffect(() => {
    const success = saveMatchData(matchData);
    if (success) {
      setIsSavedLocally(true);
      const timer = setTimeout(() => setIsSavedLocally(false), 2500);
      return () => clearTimeout(timer);
    }
  }, [matchData]);

  // Auto-adjust preview scale based on container width
  useEffect(() => {
    const updateScale = () => {
      if (previewContainerRef.current) {
        const containerWidth = previewContainerRef.current.clientWidth - 48;
        const targetScale = Math.min(Math.max(containerWidth / 1080, 0.22), 0.58);
        setPreviewScale(targetScale);
      }
    };
    updateScale();
    window.addEventListener('resize', updateScale);
    return () => window.removeEventListener('resize', updateScale);
  }, []);

  const handleSwapTeams = () => {
    setMatchData((prev) => ({
      ...prev,
      team1: { ...prev.team2 },
      team2: { ...prev.team1 },
      scorersTeam1: prev.scorersTeam2,
      scorersTeam2: prev.scorersTeam1,
    }));
  };

  const handleReset = () => {
    if (confirm('هل تريد إعادة تعيين جميع بيانات المباراة وحذف المحفوظات في المتصفح؟')) {
      clearSavedMatchData();
      setMatchData(INITIAL_MATCH_DATA);
    }
  };

  const generateFileName = () => {
    const sanitize = (str: string) =>
      str
        .trim()
        .toLowerCase()
        .replace(/[\s/\\?%*:|"<>]+/g, '-')
        .slice(0, 30);

    const t1 = sanitize(matchData.team1.name || 'team1');
    const t2 = sanitize(matchData.team2.name || 'team2');
    return `${t1}-vs-${t2}-${matchData.team1.score}-${matchData.team2.score}.png`;
  };

  const handleExport = async () => {
    if (!exportNodeRef.current) return;
    setIsExporting(true);

    try {
      // Use toPng with 1080x1350 resolution
      const dataUrl = await toPng(exportNodeRef.current, {
        width: 1080,
        height: 1350,
        pixelRatio: 1,
        quality: 1,
        cacheBust: true,
      });

      const fileName = generateFileName();
      setExportedFileName(fileName);
      setExportedImageUrl(dataUrl);
      setIsModalOpen(true);

      // Trigger download
      const link = document.createElement('a');
      link.download = fileName;
      link.href = dataUrl;
      link.click();

      // Trigger celebratory confetti
      confetti({
        particleCount: 75,
        spread: 60,
        origin: { y: 0.6 },
        colors: ['#10b981', '#d4af37', '#ffffff', '#047857'],
      });
    } catch (error) {
      console.error('Export failed:', error);
      alert('حدث خطأ أثناء تحميل التصميم، يرجى المحاولة مرة أخرى.');
    } finally {
      setIsExporting(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#070b09] text-neutral-100 flex flex-col antialiased selection:bg-emerald-500 selection:text-white" dir="rtl">
      {/* Top Bar Header */}
      <Header
        onExport={handleExport}
        onReset={handleReset}
        onSwapTeams={handleSwapTeams}
        isExporting={isExporting}
        isSavedLocally={isSavedLocally}
      />

      {/* Mobile Tab Switcher */}
      <div className="lg:hidden sticky top-[57px] z-30 bg-neutral-900/95 border-b border-neutral-800 p-2 backdrop-blur-md">
        <div className="flex rounded-xl bg-neutral-950 p-1 border border-neutral-800">
          <button
            type="button"
            onClick={() => setMobileTab('editor')}
            className={`flex-1 py-2 text-xs font-bold rounded-lg flex items-center justify-center gap-2 transition-all cursor-pointer ${
              mobileTab === 'editor'
                ? 'bg-emerald-600 text-white shadow-md'
                : 'text-neutral-400 hover:text-white'
            }`}
          >
            <Settings2 className="w-4 h-4" />
            <span>لوحة التحكم والبيانات</span>
          </button>
          <button
            type="button"
            onClick={() => setMobileTab('preview')}
            className={`flex-1 py-2 text-xs font-bold rounded-lg flex items-center justify-center gap-2 transition-all cursor-pointer ${
              mobileTab === 'preview'
                ? 'bg-emerald-600 text-white shadow-md'
                : 'text-neutral-400 hover:text-white'
            }`}
          >
            <Eye className="w-4 h-4" />
            <span>معاينة البوستر ({matchData.team1.score} - {matchData.team2.score})</span>
          </button>
        </div>
      </div>

      {/* Main Studio Viewport */}
      <main className="flex-1 max-w-[1600px] w-full mx-auto p-4 sm:p-6 lg:p-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 lg:gap-8 items-start">
          
          {/* ================= COLUMN 1: CONTROL PANEL ================= */}
          <section
            className={`lg:col-span-6 xl:col-span-6 space-y-5 ${
              mobileTab === 'preview' ? 'hidden lg:block' : 'block'
            }`}
          >
            {/* Quick Segmented Nav for Mobile / Fast scrolling */}
            <div className="flex items-center gap-1.5 p-1 bg-neutral-900/80 border border-neutral-800 rounded-xl overflow-x-auto text-xs">
              <button
                type="button"
                onClick={() => setActiveControlTab('teams')}
                className={`px-3 py-1.5 rounded-lg font-bold whitespace-nowrap transition-colors cursor-pointer ${
                  activeControlTab === 'teams'
                    ? 'bg-emerald-600 text-white shadow'
                    : 'text-neutral-400 hover:text-neutral-200'
                }`}
              >
                الفرق والنتيجة
              </button>
              <button
                type="button"
                onClick={() => setActiveControlTab('background')}
                className={`px-3 py-1.5 rounded-lg font-bold whitespace-nowrap transition-colors cursor-pointer ${
                  activeControlTab === 'background'
                    ? 'bg-emerald-600 text-white shadow'
                    : 'text-neutral-400 hover:text-neutral-200'
                }`}
              >
                صورة في الخلفية
              </button>
              <button
                type="button"
                onClick={() => setActiveControlTab('match')}
                className={`px-3 py-1.5 rounded-lg font-bold whitespace-nowrap transition-colors cursor-pointer ${
                  activeControlTab === 'match'
                    ? 'bg-emerald-600 text-white shadow'
                    : 'text-neutral-400 hover:text-neutral-200'
                }`}
              >
                معلومات المباراة
              </button>
              <button
                type="button"
                onClick={() => setActiveControlTab('template')}
                className={`px-3 py-1.5 rounded-lg font-bold whitespace-nowrap transition-colors ${
                  activeControlTab === 'template'
                    ? 'bg-emerald-600 text-white shadow'
                    : 'text-neutral-400 hover:text-neutral-200'
                }`}
              >
                القوالب (5)
              </button>
              <button
                type="button"
                onClick={() => setActiveControlTab('photo')}
                className={`px-3 py-1.5 rounded-lg font-bold whitespace-nowrap transition-colors ${
                  activeControlTab === 'photo'
                    ? 'bg-emerald-600 text-white shadow'
                    : 'text-neutral-400 hover:text-neutral-200'
                }`}
              >
                صورة المباراة
              </button>
              <button
                type="button"
                onClick={() => setActiveControlTab('scorers')}
                className={`px-3 py-1.5 rounded-lg font-bold whitespace-nowrap transition-colors ${
                  activeControlTab === 'scorers'
                    ? 'bg-emerald-600 text-white shadow'
                    : 'text-neutral-400 hover:text-neutral-200'
                }`}
              >
                الهدافين
              </button>
            </div>

            {/* TAB 1: Teams & Score */}
            {(activeControlTab === 'teams' || true) && (
              <div className={activeControlTab === 'teams' ? 'space-y-4' : 'hidden'}>
                {/* Team 1 (Derb Negm) */}
                <TeamCard
                  label="الفريق الأول (ديرب نجم)"
                  isMainTeam={true}
                  team={matchData.team1}
                  onChange={(updated) =>
                    setMatchData((prev) => ({ ...prev, team1: updated }))
                  }
                  accentColor="emerald"
                />

                {/* Team 2 (Opponent) */}
                <TeamCard
                  label="الفريق الثاني (المنافس)"
                  isMainTeam={false}
                  team={matchData.team2}
                  onChange={(updated) =>
                    setMatchData((prev) => ({ ...prev, team2: updated }))
                  }
                  accentColor="slate"
                />
              </div>
            )}

            {/* TAB: Background Image (صورة في الخلفية) */}
            {(activeControlTab === 'background' || true) && (
              <div className={activeControlTab === 'background' ? 'space-y-4' : 'hidden'}>
                <BackgroundSection
                  data={matchData}
                  onChange={(updated) =>
                    setMatchData((prev) => ({ ...prev, ...updated }))
                  }
                />
              </div>
            )}

            {/* TAB 2: Match Information */}
            {(activeControlTab === 'match' || true) && (
              <div className={activeControlTab === 'match' ? 'space-y-4' : 'hidden'}>
                <MatchDetails
                  data={matchData}
                  onChange={(updated) =>
                    setMatchData((prev) => ({ ...prev, ...updated }))
                  }
                />
              </div>
            )}

            {/* TAB 3: Template Selector */}
            {(activeControlTab === 'template' || true) && (
              <div className={activeControlTab === 'template' ? 'space-y-4' : 'hidden'}>
                <TemplatePicker
                  currentTemplate={matchData.template}
                  onSelect={(tmpl) =>
                    setMatchData((prev) => ({ ...prev, template: tmpl }))
                  }
                />
              </div>
            )}

            {/* TAB 4: Photo Uploader */}
            {(activeControlTab === 'photo' || true) && (
              <div className={activeControlTab === 'photo' ? 'space-y-4' : 'hidden'}>
                <PhotoUploader
                  photo={matchData.matchPhoto}
                  opacity={matchData.matchPhotoOpacity}
                  onPhotoChange={(photo) =>
                    setMatchData((prev) => ({ ...prev, matchPhoto: photo }))
                  }
                  onOpacityChange={(opacity) =>
                    setMatchData((prev) => ({
                      ...prev,
                      matchPhotoOpacity: opacity,
                    }))
                  }
                />
              </div>
            )}

            {/* TAB 5: Scorers and Additional Notes */}
            {(activeControlTab === 'scorers' || true) && (
              <div className={activeControlTab === 'scorers' ? 'space-y-4' : 'hidden'}>
                <ScorersSection
                  data={matchData}
                  onChange={(updated) =>
                    setMatchData((prev) => ({ ...prev, ...updated }))
                  }
                />
              </div>
            )}

            {/* Bottom Direct CTA */}
            <div className="p-4 rounded-2xl bg-gradient-to-r from-emerald-950/60 to-neutral-900 border border-emerald-500/20 flex flex-col sm:flex-row items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-black text-lg">
                  ⚽
                </div>
                <div>
                  <h4 className="font-bold text-sm text-white">
                    جاهز للمشاركة على السوشيال ميديا
                  </h4>
                  <p className="text-xs text-neutral-400">
                    دقة 1080 × 1350 بكسل مثالية لـ Facebook و Instagram
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={handleExport}
                disabled={isExporting}
                className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-black font-extrabold text-xs shadow-lg shadow-emerald-500/20 flex items-center justify-center gap-2 transition-all cursor-pointer"
              >
                <Download className="w-4 h-4" />
                <span>تصدير فوري</span>
              </button>
            </div>
          </section>

          {/* ================= COLUMN 2: LIVE PREVIEW AREA ================= */}
          <section
            ref={previewContainerRef}
            className={`lg:col-span-6 xl:col-span-6 lg:sticky lg:top-20 flex flex-col items-center ${
              mobileTab === 'editor' ? 'hidden lg:flex' : 'flex'
            }`}
          >
            {/* Preview Toolbar */}
            <div className="w-full mb-3 flex items-center justify-between px-3 py-2 bg-neutral-900/80 border border-neutral-800 rounded-xl text-xs text-neutral-300 backdrop-blur-sm">
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                <span className="font-bold">المعاينة المباشرة (Live Preview)</span>
                <span className="text-neutral-500 text-[11px] hidden sm:inline">
                  • 1080 × 1350 px
                </span>
              </div>

              {/* Zoom adjustments */}
              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  onClick={() => setPreviewScale((s) => Math.max(0.2, s - 0.05))}
                  className="p-1.5 rounded hover:bg-neutral-800 text-neutral-400 hover:text-white transition-colors"
                  title="تصغير المعاينة"
                >
                  <ZoomOut className="w-3.5 h-3.5" />
                </button>
                <span className="font-mono text-[11px] text-neutral-400 w-9 text-center">
                  {Math.round(previewScale * 100)}%
                </span>
                <button
                  type="button"
                  onClick={() => setPreviewScale((s) => Math.min(0.65, s + 0.05))}
                  className="p-1.5 rounded hover:bg-neutral-800 text-neutral-400 hover:text-white transition-colors"
                  title="تكبير المعاينة"
                >
                  <ZoomIn className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            {/* Poster Preview Frame */}
            <div className="relative w-full rounded-2xl border border-neutral-800 bg-neutral-950/70 p-4 sm:p-6 flex items-center justify-center overflow-hidden shadow-2xl">
              {/* Scaled Render Container */}
              <div
                style={{
                  width: `${1080 * previewScale}px`,
                  height: `${1350 * previewScale}px`,
                }}
                className="relative shadow-2xl rounded-2xl overflow-hidden transition-all duration-150"
              >
                <div
                  style={{
                    transform: `scale(${previewScale})`,
                    transformOrigin: 'top right',
                    width: '1080px',
                    height: '1350px',
                  }}
                  className="absolute top-0 right-0"
                >
                  <PosterCanvas data={matchData} />
                </div>
              </div>
            </div>

            {/* Mobile floating download button if in preview tab */}
            <div className="lg:hidden w-full mt-4">
              <button
                type="button"
                onClick={handleExport}
                disabled={isExporting}
                className="w-full py-3.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 text-white font-extrabold text-sm shadow-xl flex items-center justify-center gap-2"
              >
                <Download className="w-4 h-4" />
                <span>تحميل البوستر النهائي (PNG)</span>
              </button>
            </div>
          </section>

        </div>
      </main>

      {/* ================= OFF-SCREEN RENDER NODE FOR 100% CLEAN 1080x1350 EXPORT ================= */}
      <div
        style={{
          position: 'fixed',
          top: '-9999px',
          left: '-9999px',
          width: '1080px',
          height: '1350px',
          zIndex: -1,
          overflow: 'hidden',
          pointerEvents: 'none',
        }}
        aria-hidden="true"
      >
        <PosterCanvas ref={exportNodeRef} data={matchData} />
      </div>

      {/* Export Success Modal */}
      <ExportModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        imageUrl={exportedImageUrl}
        fileName={exportedFileName}
      />
    </div>
  );
}
