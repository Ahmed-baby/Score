import { PresetClub } from '../types';

// High-fidelity SVG crest for Derb Negm Sporting Club (نادي ديرب نجم الرياضي)
export const DERB_NEGM_LOGO = `data:image/svg+xml;utf8,${encodeURIComponent(`
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 340" width="300" height="340">
  <defs>
    <linearGradient id="shieldBg" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#0a4628" />
      <stop offset="50%" stop-color="#052817" />
      <stop offset="100%" stop-color="#02140b" />
    </linearGradient>
    <linearGradient id="goldGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#FFF2A3" />
      <stop offset="35%" stop-color="#D4AF37" />
      <stop offset="70%" stop-color="#AA820A" />
      <stop offset="100%" stop-color="#F3C644" />
    </linearGradient>
    <linearGradient id="emeraldGrad" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stop-color="#10B981" />
      <stop offset="100%" stop-color="#047857" />
    </linearGradient>
    <filter id="goldGlow" x="-20%" y="-20%" width="140%" height="140%">
      <feDropShadow dx="0" dy="4" stdDeviation="6" flood-color="#D4AF37" flood-opacity="0.4" />
    </filter>
  </defs>

  <!-- Outer Shield Shadow -->
  <path d="M150 15 L265 55 C265 190 220 275 150 325 C80 275 35 190 35 55 Z" fill="#000" opacity="0.35" transform="translate(0, 6)" />

  <!-- Outer Shield Golden Border -->
  <path d="M150 15 L265 55 C265 190 220 275 150 325 C80 275 35 190 35 55 Z" fill="url(#goldGrad)" filter="url(#goldGlow)" />

  <!-- Inner Dark Green Body -->
  <path d="M150 25 L253 61 C253 182 212 260 150 307 C88 260 47 182 47 61 Z" fill="url(#shieldBg)" />

  <!-- Subtle Green Ribbon Lines -->
  <path d="M150 35 L240 68 C240 170 205 245 150 288 C95 245 60 170 60 68 Z" fill="none" stroke="#10b981" stroke-width="2" opacity="0.3" />

  <!-- Top Banner -->
  <path d="M68 62 Q150 78 232 62 L238 98 Q150 114 62 98 Z" fill="url(#goldGrad)" />
  <text x="150" y="87" font-family="'Cairo', sans-serif" font-weight="900" font-size="17" fill="#062e19" text-anchor="middle" letter-spacing="1">نادي ديرب نجم</text>

  <!-- Central Star of Derb Negm (نجم) -->
  <g transform="translate(150, 155)">
    <!-- Golden Star Glow -->
    <circle r="42" fill="url(#emeraldGrad)" opacity="0.2" />
    <!-- 5-Pointed Star -->
    <path d="M0 -34 L10 -11 L34 -8 L16 8 L22 32 L0 18 L-22 32 L-16 8 L-34 -8 L-10 -11 Z" fill="url(#goldGrad)" stroke="#FFE885" stroke-width="1.5" />
    <!-- Football in center of star -->
    <circle cx="0" cy="1" r="9" fill="#FFFFFF" stroke="#062e19" stroke-width="1.5" />
    <!-- Ball Patches -->
    <polygon points="0,-4 3,-1 2,3 -2,3 -3,-1" fill="#062e19" />
  </g>

  <!-- Laurel Leaves / Wreath of Victory -->
  <g stroke="url(#goldGrad)" stroke-width="2.5" fill="none" stroke-linecap="round">
    <path d="M85 190 C78 220 100 255 130 270" />
    <path d="M215 190 C222 220 200 255 170 270" />
    <!-- Leaf nodes -->
    <circle cx="82" cy="195" r="3.5" fill="url(#goldGrad)" />
    <circle cx="88" cy="218" r="3.5" fill="url(#goldGrad)" />
    <circle cx="102" cy="242" r="3.5" fill="url(#goldGrad)" />
    <circle cx="122" cy="260" r="3.5" fill="url(#goldGrad)" />

    <circle cx="218" cy="195" r="3.5" fill="url(#goldGrad)" />
    <circle cx="212" cy="218" r="3.5" fill="url(#goldGrad)" />
    <circle cx="198" cy="242" r="3.5" fill="url(#goldGrad)" />
    <circle cx="178" cy="260" r="3.5" fill="url(#goldGrad)" />
  </g>

  <!-- Bottom Year Tag -->
  <text x="150" y="278" font-family="'Cairo', sans-serif" font-weight="700" font-size="13" fill="#D4AF37" text-anchor="middle">1976 • مصر</text>
</svg>
`)}`;

// Opponent Crest 1: Belbeis SC (نادي بلبيس الرياضي)
export const BELBEIS_LOGO = `data:image/svg+xml;utf8,${encodeURIComponent(`
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 340" width="300" height="340">
  <defs>
    <linearGradient id="blueGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#1E3A8A" />
      <stop offset="100%" stop-color="#0F172A" />
    </linearGradient>
    <linearGradient id="amberGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#F59E0B" />
      <stop offset="100%" stop-color="#B45309" />
    </linearGradient>
  </defs>
  <path d="M150 15 L260 55 C260 190 220 275 150 325 C80 275 40 190 40 55 Z" fill="url(#amberGrad)" />
  <path d="M150 25 L248 62 C248 180 210 260 150 307 C90 260 52 180 52 62 Z" fill="url(#blueGrad)" />
  <circle cx="150" cy="150" r="45" fill="#FFFFFF" opacity="0.1" />
  <text x="150" y="85" font-family="'Cairo', sans-serif" font-weight="900" font-size="18" fill="#F59E0B" text-anchor="middle">نادي بلبيس</text>
  <circle cx="150" cy="160" r="28" fill="#FFF" stroke="#1E3A8A" stroke-width="3" />
  <polygon points="150,148 160,156 156,168 144,168 140,156" fill="#1E3A8A" />
  <text x="150" y="260" font-family="'Cairo', sans-serif" font-weight="700" font-size="14" fill="#E2E8F0" text-anchor="middle">الشرقية</text>
</svg>
`)}`;

// Opponent Crest 2: Al Sharkia SC (نادي الشرقية الرياضي)
export const SHARKIA_LOGO = `data:image/svg+xml;utf8,${encodeURIComponent(`
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 340" width="300" height="340">
  <defs>
    <linearGradient id="greenSharkia" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#15803D" />
      <stop offset="100%" stop-color="#14532D" />
    </linearGradient>
  </defs>
  <path d="M150 15 L260 55 C260 190 220 275 150 325 C80 275 40 190 40 55 Z" fill="#FACC15" />
  <path d="M150 25 L248 62 C248 180 210 260 150 307 C90 260 52 180 52 62 Z" fill="url(#greenSharkia)" />
  <text x="150" y="85" font-family="'Cairo', sans-serif" font-weight="900" font-size="18" fill="#FFFFFF" text-anchor="middle">نادي الشرقية</text>
  <g transform="translate(150, 160) scale(0.9)">
    <circle r="36" fill="#FFF" />
    <path d="M-15 -10 C-10 -25 15 -25 20 -5 C25 10 15 25 -5 20 C-15 15 -20 5 -15 -10 Z" fill="#15803D" />
    <circle cx="10" cy="-10" r="2.5" fill="#FFF" />
  </g>
  <text x="150" y="260" font-family="'Cairo', sans-serif" font-weight="700" font-size="14" fill="#FACC15" text-anchor="middle">أحفاد عرابي</text>
</svg>
`)}`;

// Opponent Crest 3: Fakous SC (نادي فاقوس الرياضي)
export const FAKOUS_LOGO = `data:image/svg+xml;utf8,${encodeURIComponent(`
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 340" width="300" height="340">
  <defs>
    <linearGradient id="redGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#DC2626" />
      <stop offset="100%" stop-color="#991B1B" />
    </linearGradient>
  </defs>
  <path d="M150 15 L260 55 C260 190 220 275 150 325 C80 275 40 190 40 55 Z" fill="#E2E8F0" />
  <path d="M150 25 L248 62 C248 180 210 260 150 307 C90 260 52 180 52 62 Z" fill="url(#redGrad)" />
  <text x="150" y="85" font-family="'Cairo', sans-serif" font-weight="900" font-size="18" fill="#FFFFFF" text-anchor="middle">نادي فاقوس</text>
  <circle cx="150" cy="160" r="32" fill="#FFFFFF" stroke="#991B1B" stroke-width="4" />
  <path d="M150 142 L160 158 L150 154 L140 158 Z" fill="#991B1B" />
  <text x="150" y="260" font-family="'Cairo', sans-serif" font-weight="700" font-size="14" fill="#FFFFFF" text-anchor="middle">1968</text>
</svg>
`)}`;

// Opponent Crest 4: Generic Opponent Shield
export const GENERIC_OPPONENT_LOGO = `data:image/svg+xml;utf8,${encodeURIComponent(`
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 340" width="300" height="340">
  <defs>
    <linearGradient id="opponentGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#334155" />
      <stop offset="50%" stop-color="#1E293B" />
      <stop offset="100%" stop-color="#0F172A" />
    </linearGradient>
    <linearGradient id="silverGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#F8FAFC" />
      <stop offset="50%" stop-color="#CBD5E1" />
      <stop offset="100%" stop-color="#94A3B8" />
    </linearGradient>
  </defs>
  <path d="M150 15 L260 55 C260 190 220 275 150 325 C80 275 40 190 40 55 Z" fill="url(#silverGrad)" />
  <path d="M150 25 L248 62 C248 180 210 260 150 307 C90 260 52 180 52 62 Z" fill="url(#opponentGrad)" />
  <text x="150" y="90" font-family="'Cairo', sans-serif" font-weight="900" font-size="17" fill="#F1F5F9" text-anchor="middle">الفريق المنافس</text>
  <circle cx="150" cy="165" r="34" fill="#FFFFFF" stroke="#475569" stroke-width="3" />
  <polygon points="150,150 162,159 157,172 143,172 138,159" fill="#1E293B" />
  <text x="150" y="260" font-family="'Cairo', sans-serif" font-weight="700" font-size="14" fill="#94A3B8" text-anchor="middle">GUEST FC</text>
</svg>
`)}`;

// Default stadium background pattern (subtle stadium lights & pitch grass texture)
export const DEFAULT_STADIUM_BG = `data:image/svg+xml;utf8,${encodeURIComponent(`
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1080 1350" width="1080" height="1350">
  <defs>
    <linearGradient id="bgG" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stop-color="#02130a" />
      <stop offset="40%" stop-color="#042213" />
      <stop offset="75%" stop-color="#03180d" />
      <stop offset="100%" stop-color="#010a05" />
    </linearGradient>
    <radialGradient id="floodlight1" cx="20%" cy="10%" r="60%">
      <stop offset="0%" stop-color="#10B981" stop-opacity="0.35" />
      <stop offset="100%" stop-color="#10B981" stop-opacity="0" />
    </radialGradient>
    <radialGradient id="floodlight2" cx="80%" cy="10%" r="60%">
      <stop offset="0%" stop-color="#F59E0B" stop-opacity="0.25" />
      <stop offset="100%" stop-color="#F59E0B" stop-opacity="0" />
    </radialGradient>
    <radialGradient id="centerGlow" cx="50%" cy="45%" r="45%">
      <stop offset="0%" stop-color="#059669" stop-opacity="0.25" />
      <stop offset="100%" stop-color="#022c22" stop-opacity="0" />
    </radialGradient>
  </defs>
  <rect width="1080" height="1350" fill="url(#bgG)" />
  <rect width="1080" height="1350" fill="url(#floodlight1)" />
  <rect width="1080" height="1350" fill="url(#floodlight2)" />
  <circle cx="540" cy="650" r="450" fill="url(#centerGlow)" />
  <g stroke="#ffffff" stroke-width="2" opacity="0.04">
    <ellipse cx="540" cy="1150" rx="350" ry="120" fill="none" />
    <line x1="100" y1="1250" x2="980" y2="1250" />
    <line x1="540" y1="1000" x2="540" y2="1350" />
  </g>
</svg>
`)}`;

// Preset Background 1: Packed Stadium Night Arena
export const BG_PRESET_ARENA = `data:image/svg+xml;utf8,${encodeURIComponent(`
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1080 1350" width="1080" height="1350">
  <defs>
    <linearGradient id="skyGrad" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stop-color="#000703" />
      <stop offset="50%" stop-color="#052816" />
      <stop offset="80%" stop-color="#064223" />
      <stop offset="100%" stop-color="#031f10" />
    </linearGradient>
    <radialGradient id="lightBeam1" cx="15%" cy="15%" r="70%">
      <stop offset="0%" stop-color="#ffffff" stop-opacity="0.4" />
      <stop offset="30%" stop-color="#34d399" stop-opacity="0.2" />
      <stop offset="100%" stop-color="#047857" stop-opacity="0" />
    </radialGradient>
    <radialGradient id="lightBeam2" cx="85%" cy="15%" r="70%">
      <stop offset="0%" stop-color="#ffffff" stop-opacity="0.4" />
      <stop offset="30%" stop-color="#fbbf24" stop-opacity="0.2" />
      <stop offset="100%" stop-color="#b45309" stop-opacity="0" />
    </radialGradient>
  </defs>
  <rect width="1080" height="1350" fill="url(#skyGrad)" />
  <rect width="1080" height="1350" fill="url(#lightBeam1)" />
  <rect width="1080" height="1350" fill="url(#lightBeam2)" />
  <!-- Stadium Roof Arch -->
  <path d="M-100 450 Q540 280 1180 450 L1180 700 Q540 600 -100 700 Z" fill="#011208" opacity="0.8" />
  <!-- Crowd Silhouette Dots -->
  <g fill="#10b981" opacity="0.15">
    <ellipse cx="200" cy="800" rx="400" ry="80" />
    <ellipse cx="880" cy="800" rx="400" ry="80" />
    <ellipse cx="540" cy="850" rx="540" ry="90" />
  </g>
  <!-- Bright Pitch Field -->
  <polygon points="0,1050 1080,1050 1080,1350 0,1350" fill="#04381c" />
  <ellipse cx="540" cy="1200" rx="400" ry="120" fill="none" stroke="#34d399" stroke-width="4" opacity="0.15" />
</svg>
`)}`;

// Preset Background 2: Gold Championship Lights
export const BG_PRESET_GOLD = `data:image/svg+xml;utf8,${encodeURIComponent(`
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1080 1350" width="1080" height="1350">
  <defs>
    <linearGradient id="goldBg" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stop-color="#0a1208" />
      <stop offset="40%" stop-color="#142612" />
      <stop offset="70%" stop-color="#0d1f0c" />
      <stop offset="100%" stop-color="#050a04" />
    </linearGradient>
    <radialGradient id="goldAura" cx="50%" cy="40%" r="55%">
      <stop offset="0%" stop-color="#f59e0b" stop-opacity="0.3" />
      <stop offset="60%" stop-color="#d4af37" stop-opacity="0.08" />
      <stop offset="100%" stop-color="#050a04" stop-opacity="0" />
    </radialGradient>
  </defs>
  <rect width="1080" height="1350" fill="url(#goldBg)" />
  <circle cx="540" cy="540" r="540" fill="url(#goldAura)" />
  <!-- Confetti and Star Dust -->
  <g fill="#d4af37" opacity="0.25">
    <circle cx="150" cy="200" r="4" />
    <circle cx="320" cy="150" r="3" />
    <circle cx="850" cy="240" r="5" />
    <circle cx="950" cy="180" r="3.5" />
    <circle cx="250" cy="850" r="4" />
    <circle cx="800" cy="900" r="4.5" />
    <circle cx="180" cy="1150" r="3" />
    <circle cx="900" cy="1120" r="3.5" />
  </g>
</svg>
`)}`;

// Preset Background 3: Modern Emerald Pitch Stripes
export const BG_PRESET_TURF = `data:image/svg+xml;utf8,${encodeURIComponent(`
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1080 1350" width="1080" height="1350">
  <defs>
    <linearGradient id="turfBg" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stop-color="#02140b" />
      <stop offset="50%" stop-color="#052c17" />
      <stop offset="100%" stop-color="#010e07" />
    </linearGradient>
  </defs>
  <rect width="1080" height="1350" fill="url(#turfBg)" />
  <!-- Alternating Lawn Stripes -->
  <g opacity="0.08" fill="#10b981">
    <rect x="0" y="0" width="120" height="1350" />
    <rect x="240" y="0" width="120" height="1350" />
    <rect x="480" y="0" width="120" height="1350" />
    <rect x="720" y="0" width="120" height="1350" />
    <rect x="960" y="0" width="120" height="1350" />
  </g>
  <!-- Field perspective lines -->
  <g stroke="#ffffff" stroke-width="3" opacity="0.05">
    <line x1="540" y1="0" x2="540" y2="1350" stroke-dasharray="16 16" />
    <circle cx="540" cy="675" r="220" fill="none" />
  </g>
</svg>
`)}`;

export const PRESET_BACKGROUNDS = [
  {
    id: 'stadium-lights',
    name: 'استاد ديرب نجم (كشافات)',
    preview: DEFAULT_STADIUM_BG,
  },
  {
    id: 'arena-night',
    name: 'ليلة الملعب الحماسية',
    preview: BG_PRESET_ARENA,
  },
  {
    id: 'championship-gold',
    name: 'أجواء التتويج الذهبية',
    preview: BG_PRESET_GOLD,
  },
  {
    id: 'pitch-turf',
    name: 'أرضية العشب المخططة',
    preview: BG_PRESET_TURF,
  },
];

export const PRESET_CLUBS: PresetClub[] = [
  {
    id: 'derb-negm',
    name: 'نادي ديرب نجم',
    shortName: 'ديرب نجم',
    logo: DERB_NEGM_LOGO,
    city: 'الشرقية',
  },
  {
    id: 'generic-opponent',
    name: 'الفريق المنافس',
    shortName: 'المنافس',
    logo: GENERIC_OPPONENT_LOGO,
    city: 'الخصم',
  },
  {
    id: 'belbeis',
    name: 'نادي بلبيس الرياضي',
    shortName: 'بلبيس',
    logo: BELBEIS_LOGO,
    city: 'الشرقية',
  },
  {
    id: 'sharkia',
    name: 'نادي الشرقية',
    shortName: 'الشرقية',
    logo: SHARKIA_LOGO,
    city: 'الزقازيق',
  },
  {
    id: 'fakous',
    name: 'نادي فاقوس الرياضي',
    shortName: 'فاقوس',
    logo: FAKOUS_LOGO,
    city: 'فاقوس',
  },
];
