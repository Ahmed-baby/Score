export type TemplateId = 'dark-pro' | 'modern-light' | 'match-photo' | 'stadium-neon' | 'classic-gold';

export interface TeamData {
  name: string;
  logo: string; // Data URL or SVG string
  score: number;
  penalties?: number | null;
  shortName?: string;
}

export interface MatchData {
  team1: TeamData;
  team2: TeamData;
  headline: string; // e.g. "نِهَايَةُ الْمُبَارَاةِ"
  subheadline: string; // e.g. "النتيجة النهائية"
  date: string;
  time: string;
  stadium: string;
  tournament: string;
  round: string;
  matchPhoto: string | null;
  matchPhotoOpacity: number; // 0 to 100
  // Custom Poster Background Image (صورة في الخلفية)
  backgroundImage: string | null;
  backgroundOpacity: number; // 10 to 100
  backgroundBlur: number; // 0 to 25 px
  backgroundDarkOverlay: number; // 0 to 100
  backgroundOverlayColor?: 'black' | 'green' | 'navy' | 'vignette';
  scorersTeam1: string; // e.g. "محمد إبراهيم 32' • أحمد زكي 84'"
  scorersTeam2: string; // e.g. "محمود سالم 60'"
  showScorers: boolean;
  extraInfo: string; // e.g. "ركلات الترجيح" or "الوقت الإضافي"
  template: TemplateId;
}

export interface PresetClub {
  id: string;
  name: string;
  shortName: string;
  logo: string;
  city?: string;
}
